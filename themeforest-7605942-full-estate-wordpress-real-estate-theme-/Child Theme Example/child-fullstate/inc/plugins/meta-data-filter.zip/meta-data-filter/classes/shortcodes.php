<?php

class MetaDataFilterShortcodes extends MetaDataFilterCore {

    public static function init() {
        $args = array(
            'labels'=>array(
                'name'=>__('MDF Shortcodes', 'meta-data-filter'),
                'singular_name'=>__('Shortcodes Links', 'meta-data-filter'),
                'add_new'=>__('Add New Shortcode', 'meta-data-filter'),
                'add_new_item'=>__('Add New Shortcode', 'meta-data-filter'),
                'edit_item'=>__('Edit Shortcode', 'meta-data-filter'),
                'new_item'=>__('New Shortcode', 'meta-data-filter'),
                'view_item'=>__('View Shortcode', 'meta-data-filter'),
                'search_items'=>__('Search Shortcodes', 'meta-data-filter'),
                'not_found'=>__('No Shortcodes found', 'meta-data-filter'),
                'not_found_in_trash'=>__('No Shortcodes found in Trash', 'meta-data-filter'),
                'parent_item_colon'=>''
            ),
            'public'=>false,
            'archive'=>false,
            'exclude_from_search'=>false,
            'publicly_queryable'=>true,
            'show_ui'=>true,
            'query_var'=>true,
            'capability_type'=>'post',
            'has_archive'=>false,
            'hierarchical'=>true,
            'menu_position'=>null,
            'show_in_menu'=>'edit.php?post_type=' . self::$slug,
            'supports'=>array('title', 'excerpt'),
            'rewrite'=>array('slug'=>self::$slug_shortcodes),
            'show_in_admin_bar'=>false,
            'menu_icon'=>'',
            'taxonomies'=>array()
        );

        register_post_type(self::$slug_shortcodes, $args);

        //+++
        add_action('admin_init', array(__CLASS__, 'admin_init'), 1);

        //+++
        //add_filter('mce_buttons', array(__CLASS__, 'mce_buttons'));
        //add_filter('mce_external_plugins', array(__CLASS__, 'mce_add_rich_plugins'));
        add_shortcode('meta_data_filter_results', array(__CLASS__, 'do_meta_data_filter_shortcode'));
        add_shortcode('mdf_search_form', array(__CLASS__, 'do_mdf_search_form'));
        add_shortcode('mdf_search_button', array(__CLASS__, 'do_mdf_search_button'));
        add_action('load-post.php', array(__CLASS__, "post_inits"));
        add_action('load-post-new.php', array(__CLASS__, "post_inits"));
        add_action('save_post', array(__CLASS__, 'save_post'), 1);
        add_action("manage_" . self::$slug_shortcodes . "_posts_custom_column", array(__CLASS__, "show_edit_columns_content"));
        add_filter("manage_" . self::$slug_shortcodes . "_posts_columns", array(__CLASS__, "show_edit_columns"));
        add_action('wp_ajax_mdf_init_custom_shortcode_popup', array(__CLASS__, 'init_custom_shortcode_popup'));
        add_action('wp_ajax_mdf_draw_shortcode_html_items', array(__CLASS__, 'draw_shortcode_html_items_ajx'));
        //***
        add_action('wp_ajax_mdf_search_button_get_content', array(__CLASS__, 'mdf_search_button_get_content'));
        add_action('wp_ajax_nopriv_mdf_search_button_get_content', array(__CLASS__, 'mdf_search_button_get_content'));
    }

    public static function admin_init() {
        add_meta_box("mdf_shortcode_options", __("MDF Shortcode Options", 'meta-data-filter'), array(__CLASS__, 'draw_options_meta_box'), self::$slug_shortcodes, "normal", "high");
        add_meta_box("mdf_shortcode_shortcode", __("Shortcode", 'meta-data-filter'), array(__CLASS__, 'draw_shortcode_meta_box'), self::$slug_shortcodes, "side", "high");
    }

    public static function draw_shortcode_meta_box() {
        global $post;
        _e("<b>Search form shortcode</b>", 'meta-data-filter');
        ?>
        <br />
        <i>[mdf_search_form id="<?php echo $post->ID ?>"]</i><br /><br />
        <?php
        _e("<b>Button shortcode</b>", 'meta-data-filter');
        echo '<br /><i>[mdf_search_button id="' . $post->ID . '" title="' . $post->post_title . '" popup_width=800]</i>';
    }

    public static function show_edit_columns( $columns ) {
        $columns = array(
            "cb"=>'<input type="checkbox" />',
            "title"=>__("Title", 'meta-data-filter'),
            "shortcode"=>__("Shortcode", 'meta-data-filter'),
            "button_shortcode"=>__("Button Shortcode", 'meta-data-filter'),
            "date"=>__("Date", 'meta-data-filter'),
        );

        return $columns;
    }

    public static function show_edit_columns_content( $column ) {
        global $post;

        switch($column) {
            case "shortcode":
                echo '[mdf_search_form id="' . $post->ID . '"]';
                break;
            case "button_shortcode":
                echo '[mdf_search_button id="' . $post->ID . '" title="' . $post->post_title . '"]';
                break;
        }
    }

    public static function get_shortcode_options( $post_id ) {
        $shortcode_options = (array) get_post_meta($post_id, 'shortcode_options', true);

        if(!isset($shortcode_options['shortcode_cat']) OR empty($shortcode_options['shortcode_cat'])) {
            $shortcode_options['shortcode_cat'] = -1;
        }

        if(!isset($shortcode_options['options']['post_type']) OR empty($shortcode_options['options']['post_type'])) {
            $shortcode_options['options']['post_type'] = 'post';
        }

        return $shortcode_options;
    }

    public static function draw_options_meta_box( $post ) {
        $data = array();
        $data['post_id'] = $post->ID;
        $data['mdf_terms'] = get_terms(self::$slug_cat, array(
            'hide_empty'=>FALSE
        ));
        //+++
        $data['shortcode_options'] = self::get_shortcode_options($post->ID);
        $html_items = (array) get_post_meta($post->ID, 'html_items', true);
        $data['html_items'] = $html_items;
        echo self::render_html(self::get_application_path() . 'views/shortcode/options_meta_box.php', $data);
    }

    public static function post_inits() {
        wp_enqueue_script('mdf_shortcode', self::get_application_uri() . 'js/shortcode.js', array('jquery', 'jquery-ui-core', 'jquery-ui-draggable'));
        wp_enqueue_script('mdf_popup', self::get_application_uri() . 'js/pn_popup/pn_advanced_wp_popup.js', array('jquery', 'jquery-ui-core', 'jquery-ui-draggable'));
        wp_enqueue_style('mdf_popup', self::get_application_uri() . 'js/pn_popup/styles.css');
    }

    public static function mce_buttons( $buttons ) {
        $buttons[] = 'meta-data-filter';
        return $buttons;
    }

    public static function mce_add_rich_plugins( $plugin_array ) {
        $plugin_array['mdf_tiny_shortcodes'] = self::get_application_uri() . '/js/shortcode.js';
        return $plugin_array;
    }

//basic shortcode to show filtered results
    public static function do_meta_data_filter_shortcode() {
        $data = array();
        echo self::render_html(self::get_application_path() . 'views/shortcode/meta_data_filter.php', $data);
    }

    public static function do_mdf_search_form( $args ) {
        if(isset($args['id'])) {
            $data = array();
            $id = (int) $args['id'];
            $data['shortcode_id'] = $id;
            $post = get_post($id);
            if($post->post_status == 'publish' AND $post->post_type == self::$slug_shortcodes) {                
                self::front_script_includer();
                //+++
                $data['shortcode_options'] = self::get_shortcode_options($id);
                $data['html_items'] = self::sort_html_items((array) get_post_meta($post->ID, 'html_items', true), self::get_html_items_by_cat($data['shortcode_options']['shortcode_cat']));
                if(!is_dir(self::get_application_path() . 'views/shortcode/skins/' . $data['shortcode_options']['options']['skin'])) {
                    $data['shortcode_options']['options']['skin'] = 'default';
                }
                $data['page_meta_data_filter'] = self::get_page_mdf_data();
                wp_enqueue_style('mdf_skin_' . $data['shortcode_options']['options']['skin'], self::get_application_uri() . 'views/shortcode/skins/' . $data['shortcode_options']['options']['skin'] . '/styles.css');
                wp_enqueue_style('mdf_skin_' . $data['shortcode_options']['options']['skin'] . '_slider', self::get_application_uri() . 'views/shortcode/skins/' . $data['shortcode_options']['options']['skin'] . '/slider.css');
                echo self::render_html(self::get_application_path() . 'views/shortcode/do_mdf_search_form.php', $data);
            }
        }
    }

//ajax
    public static function init_custom_shortcode_popup() {
        $data = array();
        $data['mdf_terms'] = get_terms(self::$slug_cat, array(
            'hide_empty'=>FALSE
        ));
        wp_die(self::render_html(self::get_application_path() . 'views/shortcode/mdf_custom_popup.php', $data));
    }

//ajax
    public static function draw_shortcode_html_items_ajx() {
        wp_die(self::draw_shortcode_html_items(array('shortcode_cat'=>(int) $_REQUEST['term_id'])));
    }

    //admin
    public static function draw_shortcode_html_items( $shortcode_options/* if new */, $html_items = array() ) {
        $data = array();
        if(!isset($shortcode_options['options'])) {//if new
            $shortcode_options['options'] = array();
        }
        if(!isset($shortcode_options['options']['post_type'])) {//if new
            $shortcode_options['options']['post_type'] = 'post';
        }
        $data['shortcode_options'] = $shortcode_options;
        $html_items_by_cat = self::get_html_items_by_cat($shortcode_options['shortcode_cat']);

        //lets sort html_items as in shortcode panel
        $data['data'] = self::sort_html_items($html_items, $html_items_by_cat);

        return self::render_html(self::get_application_path() . 'views/shortcode/options_meta_box_html_items.php', $data);
    }

    //lets sort html_items as in shortcode panel
    private static function sort_html_items( $html_items, $html_items_by_cat ) {
        $html_items_by_cat_sorted = array();
        if(!empty($html_items)) {
            //sorting blocks
            foreach($html_items as $filter_id=> $meta_keys) {
                if(key_exists($filter_id, $html_items_by_cat)) {
                    $html_items_by_cat_sorted[$filter_id] = $html_items_by_cat[$filter_id];
                }
            }
            //sorting blocks items
            foreach($html_items as $filter_id=> $meta_keys) {
                if(!empty($meta_keys) AND is_array($meta_keys)) {
                    $tmp = array();
                    foreach($meta_keys as $meta_key=> $empty_val) {
                        if(isset($html_items_by_cat_sorted[$filter_id]['html_items'][$meta_key])) {
                            $tmp[$meta_key] = $html_items_by_cat_sorted[$filter_id]['html_items'][$meta_key];
                        }
                    }
                    $html_items_by_cat_sorted[$filter_id]['html_items'] = $tmp;
                }
            }
        } else {
            $html_items_by_cat_sorted = $html_items_by_cat;
        }

        return $html_items_by_cat_sorted;
    }

    public static function save_post() {
        if(!empty($_POST)) {
            global $post;
            if(is_object($post)) {
                if($post->post_type == self::$slug_shortcodes) {
                    if(isset($_POST['shortcode_options'])) {
                        update_post_meta($post->ID, 'shortcode_options', $_POST['shortcode_options']);
                        update_post_meta($post->ID, 'html_items', $_POST['html_items']); //for sorting in shortcode
                    }
                }
            }
        }
    }

    public static function get_sh_skins() {
        $skins = array();
        $src = self::get_application_path() . 'views/shortcode/skins/';
        $dir = opendir($src);
        while(false !== ( $file = readdir($dir))) {
            if(( $file != '.' ) AND ( $file != '..' )) {
                if(is_dir($src . $file)) {
                    $skins[] = $file;
                }
            }
        }
        closedir($dir);
        return $skins;
    }

    //**********************************
    public static function do_mdf_search_button( $args ) {
        if(isset($args['id']) AND is_numeric($args['id'])) {
            $rel_post = get_post($args['id']);
            if(!$rel_post) {
                return sprintf(__('Shortcode with ID %s doesn exists', 'meta-data-filter'), $args['id']);
            }
            //+++
            $shortcode_options = self::get_shortcode_options($args['id']);
            wp_enqueue_script('mdf_search_button', self::get_application_uri() . 'js/shortcodes/mdf_search_button.js', array('jquery'));
            wp_enqueue_script('mdf_popup', self::get_application_uri() . 'js/pn_popup/pn_advanced_wp_popup.js', array('jquery', 'jquery-ui-core', 'jquery-ui-draggable'));
            wp_enqueue_style('mdf_popup', self::get_application_uri() . 'js/pn_popup/styles.css');
            wp_enqueue_style('mdf_skin_' . $shortcode_options['options']['skin'], self::get_application_uri() . 'views/shortcode/skins/' . $shortcode_options['options']['skin'] . '/styles.css');
            wp_enqueue_style('mdf_skin_' . $shortcode_options['options']['skin'] . '_slider', self::get_application_uri() . 'views/shortcode/skins/' . $shortcode_options['options']['skin'] . '/slider.css');
            self::front_script_includer();
            return '<a href="#" class="mdf_search_button button" data-popup-width="' . ((isset($args['popup_width']) AND $args['popup_width'] > 0) ? $args['popup_width'] : 800) . '" data-id="' . $args['id'] . '">' . __($args['title']) . '</a>';
        }
    }

    //ajax
    public static function mdf_search_button_get_content() {
        echo '<div class="widget widget-meta-data-filter">';
        echo(do_shortcode('[mdf_search_form id="' . (int) $_REQUEST['shortcode_id'] . '"]'));
        echo '</div>';
        exit;
    }

}
