<?php if(!defined('ABSPATH')) die('No direct access allowed'); ?>
<?php
if(!isset($uniqid)) {
    $uniqid = 'medafi_' . uniqid();
}
?>
<a class="delete_item_from_data_group close-drag-holder" data-item-key="<?php echo $uniqid; ?>" href="#"></a>

<h4>
    <?php _e("Item Name", 'meta-data-filter') ?>:
</h4>

<p>
    <input type="text" placeholder="<?php _e("enter item name here", 'meta-data-filter') ?>" value="<?php echo(isset($itemdata) ? $itemdata['name'] : "") ?>" name="html_item[<?php echo $uniqid ?>][name]" />
</p>

<br />

<h4><?php _e("Item Type", 'meta-data-filter') ?>:&nbsp;</h4>

<p>
    <label class="sel">
        <select name="html_item[<?php echo $uniqid ?>][type]" class="data_group_item_select">
            <?php foreach(self::$items_types as $key=> $name) : ?>
                <option <?php echo(isset($itemdata) ? ($itemdata['type'] == $key ? "selected" : "") : "") ?> value="<?php echo $key ?>"><?php _e($name) ?></option>
            <?php endforeach; ?>            
        </select>
    </label>
</p>

<br />

<div class="data_group_item_html">

    <div class="data_group_item_template_slider data_group_input_type" style="display: <?php echo(isset($itemdata) ? ($itemdata['type'] == 'slider' ? "block" : "none") : "none") ?>">
        <h4><?php _e("From^To", 'meta-data-filter') ?></h4>
        <input type="text" placeholder="<?php _e("example", 'meta-data-filter') ?>:0^100" value="<?php echo(isset($itemdata) ? $itemdata['slider'] : '') ?>" name="html_item[<?php echo $uniqid ?>][slider]" style="width: 45%;" /><br />
        <h4><?php _e("Slider step", 'meta-data-filter') ?></h4>
        <input type="text" placeholder="<?php _e("0 or empty mean auto step", 'meta-data-filter') ?>" value="<?php echo(isset($itemdata['slider_step']) ? $itemdata['slider_step'] : '') ?>" name="html_item[<?php echo $uniqid ?>][slider_step]" style="width: 45%;" /><br />
        <h4><?php _e("Prefix", 'meta-data-filter') ?></h4>
        <input type="text" placeholder="<?php _e("Example: $", 'meta-data-filter') ?>" value="<?php echo(isset($itemdata['slider_prefix']) ? $itemdata['slider_prefix'] : '') ?>" name="html_item[<?php echo $uniqid ?>][slider_prefix]" style="width: 45%;" /><br />
        <h4><?php _e("Postfix", 'meta-data-filter') ?></h4>
        <input type="text" placeholder="<?php _e("Example: €", 'meta-data-filter') ?>" value="<?php echo(isset($itemdata['slider_postfix']) ? $itemdata['slider_postfix'] : '') ?>" name="html_item[<?php echo $uniqid ?>][slider_postfix]" style="width: 45%;" /><br />   
        <h4><?php _e("Prettify", 'meta-data-filter') ?></h4>
        <?php $slider_prettify = (isset($itemdata['slider_prettify']) ? $itemdata['slider_prettify'] : 1) ?>
        <select name="html_item[<?php echo $uniqid ?>][slider_prettify]">
            <option value="1" <?php if($slider_prettify == 1): ?>selected=""<?php endif; ?>><?php _e("Yes", 'meta-data-filter') ?></option>
            <option value="0" <?php if($slider_prettify == 0): ?>selected=""<?php endif; ?>><?php _e("No", 'meta-data-filter') ?></option>
        </select><br />
    </div>
    <div class="data_group_item_template_checkbox data_group_input_type" style="display: <?php echo(isset($itemdata) ? ($itemdata['type'] == 'checkbox' ? "block" : "none") : "none") ?>;">
        <input type="hidden" value="<?php echo(isset($itemdata) ? $itemdata['checkbox'] : 0) ?>" name="html_item[<?php echo $uniqid ?>][checkbox]" />
        <input style="display: none" type="checkbox" <?php echo(isset($itemdata) ? ($itemdata['checkbox'] ? "checked" : "") : "") ?> class="mdf_option_checkbox" />
    </div>
    <div class="data_group_item_template_select data_group_input_type" style="display: <?php echo(isset($itemdata) ? ($itemdata['type'] == 'select' ? "block" : "none") : "none") ?>;">
        <h4><?php _e("Drop-down size", 'meta-data-filter') ?>:</h4>
        <input type="text" placeholder="<?php _e("enter a digit from 1 to ...", 'meta-data-filter') ?>" value="<?php echo(isset($itemdata['select_size']) ? $itemdata['select_size'] : 1) ?>" name="html_item[<?php echo $uniqid ?>][select_size]" style="width: 45%;" /><br />
        <h4><?php _e("Drop-down first option title", 'meta-data-filter') ?>:</h4>
        <input type="text" placeholder="<?php _e("Any", 'meta-data-filter') ?>" value="<?php echo(isset($itemdata['select_option_title']) ? $itemdata['select_option_title'] : '') ?>" name="html_item[<?php echo $uniqid ?>][select_option_title]" style="width: 45%;" /><br />
        <i><?php _e("Leave this field empty to use defined in widget string: Any", 'meta-data-filter') ?></i><br />
        <h4><?php _e("Hide item name", 'meta-data-filter') ?>:</h4>
        <?php $hide_select_title = (isset($itemdata['hide_select_title']) ? $itemdata['hide_select_title'] : 0); ?>
        <select name="html_item[<?php echo $uniqid ?>][hide_select_title]">
            <option value="0" <?php if($hide_select_title == 0): ?>selected=""<?php endif; ?>><?php _e("No", 'meta-data-filter') ?></option>
            <option value="1" <?php if($hide_select_title == 1): ?>selected=""<?php endif; ?>><?php _e("Yes", 'meta-data-filter') ?></option>
        </select><br />
        <br />
        <a href="#" class="add_option_to_data_item_select button" data-append="0" data-group-index="" data-group-item-index="<?php echo $uniqid ?>"><?php _e("Prepend drop-down option", 'meta-data-filter') ?></a><br />
        <br /><br />
        <ul class="data_item_select_options">

            <?php if(isset($itemdata)): ?>

                <?php if(!empty($itemdata['select'])): ?>
                    <?php foreach($itemdata['select'] as $value) : ?>
                        <li><input type="text" name="html_item[<?php echo $uniqid ?>][select][]" value="<?php echo $value ?>">&nbsp;<a class="delete_option_from_data_item_select remove-button" href="#"></a><br></li>
                    <?php endforeach; ?>
                <?php endif; ?>

            <?php endif; ?>

        </ul>
        <br />
        <a href="#" class="add_option_to_data_item_select button" data-append="1" data-group-index="" data-group-item-index="<?php echo $uniqid ?>"><?php _e("Append drop-down option", 'meta-data-filter') ?></a><br />

    </div>


    <div class="data_group_item_template_taxonomy data_group_input_type" style="display: <?php echo(isset($itemdata) ? ($itemdata['type'] == 'taxonomy' ? "block" : "none") : "none") ?>">
        <i><?php _e("By logic here must be taxonomies constructor. But, to add more flexibility to the plugin,  taxonomies are selected in the widget. So you can use the same group for different post types, or the same post type but different widgets. If there no taxonomies selected in the widget - nothing will appear on front of site in search form of the widget.", 'meta-data-filter') ?></i>
    </div>

    <h4><?php _e("Item Description", 'meta-data-filter') ?>:</h4>

    <textarea name="html_item[<?php echo $uniqid ?>][description]"><?php echo(isset($itemdata) ? $itemdata['description'] : "") ?></textarea><br />

    <h4><?php _e("Item meta key", 'meta-data-filter') ?>:</h4>
    <input type="text" placeholder="medafi_total_sales" value="<?php echo $uniqid ?>" name="html_item[<?php echo $uniqid ?>][meta_key]" style="width: 45%;" />&nbsp;<a href="#" class="button mdf_change_meta_key_butt" data-old-key="<?php echo $uniqid ?>"><?php _e("change meta key", 'meta-data-filter') ?></a><br />
    <i><b style="color: red;"><?php _e("Attention", 'meta-data-filter') ?></b>: <?php _e("meta key must be begin from <b>medafi_</b> prefix, another way you will have problems! If you are using this key somewhere in code be ready to change it there!<br /> Change keys please for saved filter and filters items only, not for new and just created!", 'meta-data-filter') ?></i><br />
    <br />
    <h4><?php _e("Reflect value from meta key", 'meta-data-filter') ?>:</h4>
    <?php
    $is_reflected = isset($itemdata['is_reflected']) ? $itemdata['is_reflected'] : 0;
    $reflected_key = isset($itemdata['reflected_key']) ? $itemdata['reflected_key'] : '';
    ?>
    <input type="hidden" name="html_item[<?php echo $uniqid ?>][is_reflected]" value="<?php echo $is_reflected ?>" />
    <input type="checkbox" class="mdf_is_reflected" <?php if($is_reflected): ?>checked<?php endif; ?> />&nbsp;<input type="text" <?php if(!$is_reflected): ?>disabled<?php endif; ?> placeholder="<?php if(!$is_reflected): ?>disabled<?php else: ?>enabled<?php endif; ?>" value="<?php echo trim(esc_attr($reflected_key)) ?>" name="html_item[<?php echo $uniqid ?>][reflected_key]" style="width: 45%;" /><br />
    <i><?php _e("Example: <b>_regular_price</b>, where <i>_regular_price</i> is reflected meta field key in products.<br /> Reflection synchronizes data with already existing meta keys and makes them searchable!", 'meta-data-filter') ?></i>
</div>

