=== Advanced Custom Fields: Icon Field ===
Author: Jorge L. Dorta Palmero
Author URI: http://www.jldorta.com
Requires at least: 3.0
Tested up to: 3.5.1
Version: 0.5.a


== Copyright ==
Copyright 2014 Jorge L. Dorta Palmero

This software is NOT to be distributed, but can be INCLUDED in WP themes: Premium or Contracted.
This software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
