<?php
    $maison_key = $maison_value['rpt'];         
 ?>

<div class="container">
  <div class="row">
    <div class="col-md-12">
        <?php                
            echo html_entity_decode($maison_key['content']);
        ?>
      </div>
	</div>
</div>