<?php
    global $maison_pos;
    the_post();                               
    $maison_day = get_the_time('j');
    $maison_month = get_the_time('M');
    $maison_year = get_the_time('Y');

    if($maison_pos == 1){
        echo '<div class="col-md-3">'; 
            get_sidebar(); 
        echo '</div>';
    } 
    
    $maison_icons = (function_exists('get_field'))?get_field('icons'):array();
    $maison_icons = (!empty($maison_icons))?$maison_icons[0]:$maison_icons;
?>

<div class="<?php echo $maison_pos == 2 ? 'row' : 'col-md-9';?>">
    <div class="post single">
        
        <div class="clearfix"></div> 
          <div class="col-md-12">
              <a href="<?php the_permalink();?>"><h2><?php the_title();?></h2></a>
              <ul class="meta">
                <li class="author">
                  <i class="icon-user"></i>
                    <a href="#"> <?php the_author();?></a>
                  </li>
                <li class="comments-numb">                                    
                  <i class="<?php echo $maison_icons['coment_icon'];?>"></i>
                  <a href="<?php the_permalink();?>"><?php comments_number();?></a>
                </li>
                <li>
                    <i class="icon-calendar"></i>
                    <?php echo $maison_day;?> -<?php echo $maison_month;?>
                </li>
              </ul>
              
        </div>
    </div>
    <?php comments_template(); ?>
</div>

<?php
    if($maison_pos == 3){
       echo '<div class="col-md-3">'; 
            get_sidebar(); 
       echo '</div>';
    }    
?>   