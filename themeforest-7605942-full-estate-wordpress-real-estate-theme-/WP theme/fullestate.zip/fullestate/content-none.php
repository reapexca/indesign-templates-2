<div class="item_blog">
    <h1 style="color:#000 !important;">Nothing Found</h1><p style="color:#000 !important;">Sorry, but nothing matched your search terms. Please try again with some different keywords.</p>
    <?php get_search_form()?>
</div>   
