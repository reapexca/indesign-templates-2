<?php
/*
Template Name: Template Properties
*/

get_header();
      
global $maison_filter_form;
if(function_exists('get_field'))
    if(get_field('filter_tabs') !== false){
        foreach(get_field('filter_tabs') as $maison_f){
            $maison_filter_form[] = $maison_f; 
        }
    }
$GLOBALS['sidebar_news'] = (get_field('sidebar_name') !== false && get_field('sidebar_name') !== '') ? get_field('sidebar_name') : 'filter';
    
$_SESSION['FILTER_FORM'] = $maison_filter_form;
$maison_current_ID = get_the_ID();

$maison_layout = isset($_REQUEST['layout']) ? $_REQUEST['layout'] : get_field('style_property');
$_COOKIE['layout'] = (isset($_GET['layout'])) ? $_GET['layout'] : $maison_layout;

if(function_exists('get_field')){
    $GLOBALS['sidebar_name'] = (get_field('sidebar_name') !== '')?get_field('sidebar_name'):'filter';
    $maison_pos = (get_field('position') !== '')?get_field('position'):'3';
    $maison_number_properties = (get_field('num_properties') !== false)?get_field('num_properties'):'3';
    $maison_acor = (get_field('rpt-acordion') !== false)?get_field('rpt-acordion'):array();
}
if(!function_exists('get_field')){
$maison_post = get_post();
    if(!empty($maison_post->post_content)){
        echo '<section class="section_area">
                <div class="container">
                    <div class="row">';
                echo $maison_post->post_content;
                echo '</div>
                </div>
            </section>';
    }
}else{
?>

<div class="container">
  <div class="row paddings">
    
    	<?php
  			if($maison_pos == '1'){
            echo '<div class="col-md-4 col-lg-3"><aside';
                get_sidebar($GLOBALS['sidebar_news']);
            echo '</aside>';
        }
  		?>

  
      <div class="<?php echo ($maison_pos != '2')?'col-md-8 col-lg-9':'col-md-12'; echo ($maison_layout == 'box')?' properties_two':'';?> counter-page" data-count="<?php echo $maison_number_properties;?>">
          
          	<!-- Bar properties-->
            <div id="bar" class="bar_properties">
                <div class="row">
                    <div class="col-md-8">
                        <strong><?php echo of_get_option('order_bar'); ?></strong>
                        <ul class="tooltip_hover">                            
                            <li>
                                <a href="#"><?php echo of_get_option('order_recent'); ?></a>
                                <a href="#" data-toggle="tooltip" title="<?php echo of_get_option('sort_a'); ?>" class="btn_order"  data-order="asc" data-type="date">
                                    <i class="icon-caret-up"></i>
                                </a>
                                <a href="#" data-toggle="tooltip" title="<?php echo of_get_option('sort_d'); ?>" class="btn_order" data-order="desc" data-type="date">
                                    <i class="icon-caret-down"></i>
                                </a>
                            </li>
                            <li>
                              <a href="#"><?php echo of_get_option('order_prices'); ?></a>
                              <a href="#" data-toggle="tooltip" title="<?php echo of_get_option('sort_a'); ?>" class="btn_order" data-order="asc" data-type="price">
                                  <i class="icon-caret-up"></i>
                              </a>
                              <a href="#" data-toggle="tooltip" title="<?php echo of_get_option('sort_d'); ?>" class="btn_order" data-order="desc" data-type="price">
                                  <i class="icon-caret-down"></i>
                              </a>
                            </li>                            
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <ul class="text_right tooltip_hover">
                            <li title="<?php echo of_get_option('grid_layout_bar'); ?>" data-toggle="tooltip" class="<?php echo (($maison_layout == 'box') ? 'active' : '') ?>">
                              <a href="<?php echo add_query_arg(array('layout' => 'box')) ?>">
                                <i class="icon-th-large"></i>
                              </a>
                            </li>
                            <li title="<?php echo of_get_option('list_layout_bar'); ?>" data-toggle="tooltip" class="<?php echo (($maison_layout == 'list') ? 'active' : '') ?>">
                              <a href="<?php echo add_query_arg(array('layout' => 'list')) ?>">
                                <i class="icon-list"></i>
                              </a>
                            </li> 
                        </ul>
                    </div>
                </div>
            </div>
            <!-- End Bar properties-->
            <?php
                   $maison_paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                    
                    $maison_args=array(
                        'post_type' => 'property',
                        'post_status' => 'publish',
                        'paged' => $maison_paged,
                        'posts_per_page' => -1,
                        'order' => 'ASC',
                    );
                    $maison_my_query = null;
                    $maison_my_query = new WP_Query($maison_args);
                    $maison_request = array();
                    
                    while ($maison_my_query->have_posts()) {
                        $maison_my_query->the_post();
                        $maison_property[] = array(
                            'ptitle' => get_the_title(),
                            'images' => get_field('images'),
                            'type' => get_field('type'),
                            'area' => get_field('area'),
                            'location' => get_field('location'),
                            'desc' => get_field('description'),
                            'date' => get_the_time('Ymd'),
                            'full_price' => get_field('price_unit').' '.get_field('price'),
                            'price' => get_field('price'),
                            'permalink' => get_permalink(get_the_ID()),
                            'generals' => get_field('general_prop'),
                        );
                    }
                    
                    $maison_c = 0;
                    $maison_count = 0;
  
                     echo ($maison_layout == 'box')?'<div class="row"><div class="order-container" data-cprop="'.count($maison_property).'" data-layout="box">':'<div class="order-container" data-cprop="'.count($maison_property).'" data-layout="home-list">';
  
                    foreach($maison_property as $maison_value){
                        $maison_aux = $maison_number_properties;
                        $maison_count = ($maison_c%$maison_aux == 0)?$maison_count+1:$maison_count;
                        $maison_c++;
                        if($maison_layout == 'box'){
                          
                            $maison_style_box = ($maison_pos == '3')?'col-md-3':'col-xs-12 col-sm-6 col-md-6 col-lg-4';
                            echo '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4 order show-off show'.$maison_count.'" data-price="'.$maison_value['price'].'" data-date="'.$maison_value['date'].'" data-type="'.$maison_value['type'].'">';
                              echo '<div class="item_property">
                                      <div class="head_property">';
                                      echo '<a href="'.$maison_value['permalink'].'">';
                                            echo '<div class="title '.strtolower($maison_value['type']).'"></div>';
                                           echo ($maison_value['images'] !== null)?'<img src="'.$maison_value['images'][0]['url'].'" alt="Image">':'<img src="" alt="Not Image">';
                                       	   echo '<h5>'.$maison_value['ptitle'].'</h5>';
                                      echo '</a>
                                      </div>                      
                                      <div class="info_property">'; ?>  
          						                  <ul class="info_details">
                                        <?php
                                            if(!empty($maison_value['generals']))
                                            foreach($maison_value['generals'] as $k=>$g){
                                                echo ($k%2 == 0)?'<li class="resalt"><strong>'.$g['title'].'</strong><span>'.$g['value'].'</span></li>':'<li><strong>'.$g['title'].' </strong><span>'.$g['value'].'</span></li>';
                                            }
                                        ?>            
                                         </ul>
                         <?php echo '</div>
                                </div>
                            </div>';
                        
                        }
                        else if($maison_layout == 'list'){ 

                          echo '<article class="item_property_h order show-off show'.$maison_count.'" data-price="'.$maison_value['price'].'" data-date="'.$maison_value['date'].'" data-type="'.$maison_value['type'].'">';
                            echo '<div class="col-md-4">
                                    <div class="image_property_h">                            
                                        <div class="hover_property_h">';
                                        echo ($maison_value['images'] !== null)?'<img src="'.$maison_value['images'][0]['url'].'" alt="Image List">':'<img src="" alt="Not Image">';
                                         echo '<a href="'.$maison_value['permalink'].'" class="info_hover_property_h">';
                                                  echo '<span class="listing-cover-plus">+</span>
                                              </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="info_property_h">';
                                      echo '<h4><a href="'.$maison_value['permalink'].'">'.$maison_value['ptitle'].'</a><span> '.$maison_value['location'].' </span></h4> ';
                                      echo '<p>'.wp_trim_words($maison_value['desc'],58,'...').'</p>';
                             echo '</div>
                               </div>';
                            echo '<div class="line_property"><span>'.$maison_value['full_price'].'</span>For '.$maison_value['type'].'</div>';
                      echo '</article>'; 
                    }
                 }
               echo ($maison_layout == 'box')?'</div></div>':'</div>';
            ?>
            <!-- Pagination-->
            <ul class="pagination page-my">
            <?php
                for($i=1; $i<=ceil(count($maison_property)/$maison_number_properties); $i++){
                    echo ($i == 1)?'<li data-in="'.$i.'" class="active"><a href="#">'.$i.'</a></li>':'<li data-in="'.$i.'"><a href="#">'.$i.'</a></li>';
                }    
            ?>
            </ul>
            <!-- End Pagination-->
        </div>
<?php
        if($maison_pos == '3'){
            echo '<div class="col-md-4 col-lg-3">
  									<aside';
            get_sidebar($GLOBALS['sidebar_news']);
           		 echo '</aside>
  							</div>';
        }
        
echo '</div>
		</div>';
}
    get_footer();
?>