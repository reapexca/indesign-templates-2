<?php
/**
 * The filter Sidebar
 *
 * @package WordPress
 * @subpackage Full Estate
 * @since Full Estate
 */
 
$maison_sidebar = isset($GLOBALS['sidebar_filter'])? strtolower($GLOBALS['sidebar_filter']):'filter'; 
if ( ! is_active_sidebar( $maison_sidebar ) ) {
	return;
}
?>

<div id="supplementary">
	<div class="widget-area" role="complementary">
				<?php 
           dynamic_sidebar( $sidebar ); 
        ?>
    </div>
</div>