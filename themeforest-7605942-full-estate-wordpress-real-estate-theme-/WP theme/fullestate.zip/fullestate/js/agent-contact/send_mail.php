<?php
	$to = $_REQUEST[from]; 
	$subject = $_REQUEST[location];
	$date = date ("l, F jS, Y"); 
	$time = date ("h:i A"); 	
	$Email=$_REQUEST['Email'];

	$msg="
	Name: $_REQUEST[Name]
	Email: $_REQUEST[Email]
	
	Message sent from website on date  $date, hour: $time.\n

	Message:
	$_REQUEST[message]";

	if ($Email=="") {
		echo "Please enter your email";
	}
	else{
		mail($to, $subject, $msg, "From: $_REQUEST[Email]");
		echo "Thank you for your message...";	
	}
	
?>
