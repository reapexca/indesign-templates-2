<?php
/**
 * The Newsletter Sidebar
 *
 * @package WordPress
 * @subpackage Full Estate
 * @since Full Estate
 */
$maison_sidebar = isset($GLOBALS['sidebar_news'])? strtolower($GLOBALS['sidebar_news']):'newsletter'; 
if ( ! is_active_sidebar( $maison_sidebar ) ) {
	return;
}
?>
<div id="supplementary">
	<div class="widget-area" role="complementary">
		<?php 
				dynamic_sidebar( $maison_sidebar ); 
     ?>
    </div>
</div>