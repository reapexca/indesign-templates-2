<?php
    /*
      Template Name: Template Sidebar
    */
    get_header();
    $GLOBALS['sidebar_name'] = (function_exists('get_field'))?get_field('sidebar_name'):'primary';
    $maison_pos = (function_exists('get_field'))?get_field('position'):'3';
?>
		<div class="container"> 
        <div class="row paddings">    
          <?php
               if( $maison_pos == '1'){
                   echo '<div class="col-md-3">';
                   					get_sidebar();
                   echo '</div>';
               }
            
                echo $maison_pos == '2'?'<div class="col-md-12">':'<div class="col-md-9">';
             
                $maison_post = get_post();
                if(!empty($maison_post->post_content)){
                    $maison_explo = explode('<!--more-->', $maison_post->post_content);
                    $maison_content = '';
                    foreach($maison_explo as $t){$maison_content .= $t;}
                       echo apply_filters('the_content', $maison_content); 
                }
                echo '</div>';
							
                
               if($maison_pos == '3'){
                   echo '<div class="col-md-3">';
                   					get_sidebar();
                   echo '</div>';
               }
           ?>
        </div>
		</div>
<?php
     get_footer();
 ?>