<?php
    get_header();
    $maison_pos = (isset($_REQUEST['post_side']))?$_REQUEST['post_side']:3;              
    $GLOBALS['sidebar_name'] = (isset($_REQUEST['post_sidebar']))?$_REQUEST['post_sidebar']:'primary';              
    $maison_title = '';
    $maison_subtitle = '';
    $maison_img = '';
?>

<div class="container">
   <div class="row paddings">
     	<div class="col-md-9">

        <?php
          $maison_paginar=1;
          $maison_paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
          $maison_catID = get_query_var('tag');
          $maison_post_per_page = get_query_var('post_per_page');
          query_posts('tag='.$maison_catID.'&posts_per_page='.$maison_post_per_page.'&paged='.$maison_paged);
          while (have_posts()) {  
            the_post();                               
            $maison_day = get_the_time('j');
            $maison_month = get_the_time('M');
            $maison_year = get_the_time('Y');
            
              $maison_link = add_query_arg(array(
                'post_side' => $maison_pos,
                'post_tit' => $maison_title,
                'post_subti' => $maison_subtitle,
                'post_img' => $maison_img,
              ),get_permalink()
            );
            
        		$maison_icons = (function_exists('get_field'))?get_field('icons'):array();
            $maison_icons = (!empty($maison_icons))?$maison_icons[0]:$maison_icons;
         $maison_format = get_post_format();
                if ( false === $maison_format ) {
                  $maison_format = 'standard';
               }
          ?>
           
        	  <?php
                  // Link Post Format
                  if($maison_format == 'link'){
						  ?>
                       <div class="row post">
                          <div class="col-md-12 text-center paddings">
                            	<ul class="meta">
                                  <li class="author">
                                    <i class="icon-user"></i>
                                    <a href="<?php echo $maison_link;?>"> <?php the_author();?></a>
                                	</li>
                                  <li class="comments-numb"> 
                                    	<i class="<?php echo isset($maison_icons)? $maison_icons['coment_icon'] : '';?>"></i>
                                      <a href="<?php echo $maison_link;?>"><?php comments_number();?></a></li>
                                  </li>
                              </ul>
                              <div class="format-link"> <?php the_content();?></div>
                          </div>
                      </div>
                     <?php
                          }// End Link Post Format
                          else
                      ?>    	
										
										<?php
  	                      // Standart Post Format
	                     		if($maison_format == 'standard'){
                     ?>
                       <div class="row post">
                           <div class="col-md-12">
                              <a href="<?php echo $maison_link;?>">
                                  <h2><?php the_title();?></h2>
                              </a>
                              
                              <ul class="meta">
                                  <li class="author">
                                    <i class="icon-user"></i>
                                    <a href="<?php echo $maison_link;?>"> <?php the_author();?></a>
                                	</li>
                                  <li class="comments-numb"> 
                                    	<i class="<?php echo isset($maison_icons)? $maison_icons['coment_icon'] : '';?>"></i>
                                      <a href="<?php echo $maison_link;?>"><?php comments_number();?></a></li>
                                  </li>
                              </ul>
                              <p><?php echo wp_trim_words(get_the_content(),58,'...');?></p>
                              <a href="<?php echo $maison_link;?>" class="button"><?php echo (function_exists('of_get_option'))?of_get_option('title_button_post'):'Read More'; ?></a>
                          </div>
                      </div>
                     <?php
                          }// End Standart Post Format
                          else
                      ?>   
									
										<?php
  	                      // Quote  Post Format
	                     		if($maison_format == 'quote'){
                     ?>
                       <div class="row post">
                           <div class="col-md-12">
                              <a href="<?php echo $maison_link;?>">
                                  <h2><?php the_title();?></h2>
                              </a>
                              
                              <ul class="meta">
                                  <li class="author">
                                    <i class="icon-user"></i>
                                    <a href="<?php echo $maison_link;?>"> <?php the_author();?></a>
                                	</li>
                                  <li class="comments-numb"> 
	                                    <i class="<?php echo isset($maison_icons)? $maison_icons['coment_icon'] : '';?>"></i>
                                      <a href="<?php echo $maison_link;?>"><?php comments_number();?></a></li>
                                  </li>
                              </ul>
                              <p class="quote-format">
                                <i class="icon-quote-left"></i>
	                                <?php echo wp_trim_words(get_the_content(),58,'...');?>
                         				<i class="icon-quote-right"></i>
                         			</p>
                          </div>
                      </div>
                     <?php
                          }// End Quote  Post Format
                          else
                      ?>   

											
											<?php
  	                      // Audio  Post Format
	                     		if($maison_format == 'audio'){
                     	?>
                       <div class="row post audio_post">
                           <div class="col-md-12">
                             	
                             <?php 
                             	if(function_exists('get_field')){
                                   echo get_field('audio'); 
                               }
                             ?>
                             
                              <a href="<?php echo $maison_link;?>">
                                  <h2><?php the_title();?></h2>
                              </a>
                              
                              <ul class="meta">
                                  <li class="author">
                                    <i class="icon-user"></i>
                                    <a href="<?php echo $maison_link;?>"> <?php the_author();?></a>
                                	</li>
                                  <li class="comments-numb"> 
                                    	<i class="<?php echo isset($maison_icons)? $maison_icons['coment_icon'] : '';?>"></i>
                                      <a href="<?php echo $maison_link;?>"><?php comments_number();?></a></li>
                                  </li>
                              </ul>
                              <p><?php echo wp_trim_words(get_the_content(),58,'...');?></p>
                         			<a href="<?php echo $maison_link;?>" class="button"><?php echo (function_exists('of_get_option'))?of_get_option('title_button_post'):'Read More'; ?></a>
                          </div>
                      </div>
                     <?php
                          }// End Quote  Post Format
                          else
                      ?> 


											<?php
  	                      // Other  Post Format
	                     		if($maison_format !== 'standard' & $maison_format !== 'link' & $maison_format !== 'quote' & $maison_format !== 'audio'){
                     	?>
                          
											<div class="row post">
                        	 <div class="col-md-5">
                             <div class="image_post">
                                  <?php
                                      $maison_img = false;
                                      $maison_video = false;
                                      $maison_gallery = false;
                                      if(function_exists('get_field')){
                                          $maison_gallery = get_field('gallery_img');
                                          $maison_video = get_field('video');
                                          $maison_img = get_field('image');
                                      }
                                      if($maison_format == 'gallery' || $maison_format == 'video'){
                                          if($maison_gallery !== false){
                                                echo $maison_gallery;                       
                                          }if($maison_video !== false){
                                              echo $maison_video;
                                          }else{ 
                                              if( has_post_thumbnail($post->ID) ) { the_post_thumbnail('full', array('alt'=>$post->post_title)); }
                                              else { echo '<img src="' . get_template_directory_uri('template_directory') . '/img/default.jpg" alt="Default Image"/>'; }
                                          }
                                      }else{ 
                                          if ($maison_img != false)
                                              echo '<img src="'.$maison_img['url'].'" alt="Default Image"/>';
                                          else
                                          if( has_post_thumbnail($post->ID) ) { the_post_thumbnail('full', array('alt'=>$post->post_title)); }
                                          else { echo '<img src="' . get_template_directory_uri('template_directory') . '/img/default.jpg" alt="Default Image"/>'; }
                                      }
                                  ?>
                                  <ul>
                                    <li><?php echo $maison_day;?> -<?php echo $maison_month;?></li>
                                    <li><a href="<?php echo $maison_link;?>"><i class="<?php echo isset($maison_icons)? $maison_icons['post_icon']:'';?>"></i></a></li>
                                  </ul>
                              </div>
                          </div>
                        
                          <div class="col-md-7">
                              <a href="<?php echo $maison_link;?>">
                                  <h2><?php the_title();?></h2>
                              </a>
                              <ul class="meta">
                                  <li class="author">
                                    <i class="icon-user"></i>
                                    <a href="<?php echo $maison_link;?>"> <?php the_author();?></a>
                                	</li>
                                  <li class="comments-numb"> 
	                                    <i class="<?php echo isset($maison_icons)? $maison_icons['coment_icon'] : '';?>"></i>
                                      <a href="<?php echo $maison_link;?>"><?php comments_number();?></a></li>
                                  </li>
                              </ul>
                              <p><?php echo wp_trim_words(get_the_content(),38,'...');?></p>
                              <a href="<?php echo $maison_link;?>" class="button"><?php echo (function_exists('of_get_option'))?of_get_option('title_button_post'):'Read More'; ?></a>
                          </div>
                      </div>
        
              <?php
                  }
                }     
    				?>
                   
             <ul class="pagination">
                <?php 
                  if ($maison_paginar == '1'){ 
                    maison_pagination();
                  }else{
                    next_posts_link('&larr; '.'Older posts', 'mythemeshop' ); 
                    previous_posts_link('Maison posts'.' &rarr;', 'mythemeshop' ); 
                  }
                ?>
             </ul>
        </div>
        
        <?php
          echo '<div class="col-md-3">'; 
          			get_sidebar(); 
          echo '</div>';
        ?>
			</div>
	</div>
<?php
     get_footer();
?>