<?php
    get_header();
    $maison_price = get_field('price');
    $maison_area = get_field('area');     
?>   
 <div class="container">
        
        <div class="row">
            <div class="filter-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">';
                        <?php
                        $maison_filters = (function_exists('of_get_option'))?of_get_option('single_property_shortcode'):'';
                        if($maison_filters !== false && $maison_filters !== ''){
                            if(!empty($maison_filters))
                                do_shortcode($maison_filters);    
                                the_post();
                        }
                        ?>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
 
      		<div class="row paddings">
           	<div class="col-md-8">
                <div class="more_slide">
                    <ul class="tooltip_hover">
                    
                        <?php 
                        $maison_utils = (get_field('utils') !== false)?get_field('utils'):array();
                        foreach($maison_utils as $maison_link ){
                        ?>
                            <li data-toggle="tooltip" title data-original-title="<?php echo $maison_link['tooltip']; ?>">
                              	<i class="<?php echo $maison_link['icon']; ?>"></i>
                              	<a href="<?php echo $maison_link['link']; ?>"><?php echo $maison_link['text']; ?></a>
                      			</li>
                        <?php } ?>
                  	</ul>
               	</div>
             
                 <!-- Slide News-->           
                 <div class="camera_wrap camera_white_skin" id="slide_details">
                    <?php
                      $maison_images = (get_field('images') !== '' && get_field('images') !== false)?get_field('images'):array(); 
                      foreach($maison_images as $maison_image ){
                    ?>
                   <!-- Item Slide -->
                   <div  data-src="<?php echo $maison_image['url'] ?>">
                       <div class="camera_property fadeFromBottom">
                           	<h4><?php the_field('slide_title'); ?></h4>
                           	<h1><span><?php echo get_field('price_unit')." ".$maison_price;?></span></h1> 
                         		<p><?php the_field('slide_subtitle'); ?></p>            
                       </div>
                   </div>
                   <!-- End Item Slide -->
                   <?php }?>  
                 </div>
                 <!-- End Slide-->  
            </div>
      
            <div class="col-md-4">
                <div class="description">
                  	<div class="title <?php the_field('type'); ?>"></div>
                  
                    <h4><?php the_field('title'); ?></h4>
                    <p><?php the_field('description'); ?></p>
                  
                    <h4><?php the_field('subtitle'); ?></h4>
                    <ul class="info_details">            
                      <li><strong><?php echo of_get_option('title_price_description'); ?>:</strong><span> <?php echo get_field('price_unit').$maison_price; ?>  </span></li>
                      <li><strong><?php echo of_get_option('title_location_description'); ?>:</strong><span> <?php the_field('location'); ?> </span></li>
                      <li><strong><?php echo of_get_option('title_area_description'); ?>:</strong><span> <?php echo $maison_area.' '.get_field('area_unit'); ?>  </span></li>
                      <?php foreach(get_field('generals') as $maison_item ) {?>
                      <li><strong><?php echo $maison_item['title'] ?></strong><span> <?php echo $maison_item['value'] ?>  </span></li>
                      <?php } ?>         
                    </ul>
                 </div>
             </div> 
     			</div> 
				
   		<div class="row">
            <div class="col-md-12">
                
                  <!--NAV TABS-->
                  <ul class="tabs"> 
                      <li><a href="#tab1"><?php echo of_get_option('tab_1_single'); ?></a></li> 
                      <li><a href="#tab2"><?php echo of_get_option('tab_2_single'); ?></a></li>                                             
                      <li><a href="#tab3"><?php echo of_get_option('tab_3_single'); ?></a></li>                                              
                  </ul>                       
                            
                	<!--CONTAINER TABS-->   
                  <div class="tab_container"> 
                      <!--Tab1 Genral info-->      
                      <div id="tab1" class="tab_content">
                          <div class="row">
                              <div class="col-md-6">
                                  <h4><?php the_field('title_features'); ?></h4>
                                  <div class="row">
                                  <?php 
                                      $maison_j = 0;
                                      $maison_p = 0;
                                      $maison_features = get_field('features');
                                      $maison_total = count($maison_features);
                                      for($maison_i = 3; $maison_i > 0; $maison_i--){
                                          $maison_total -= $maison_j;
                                  ?>
                                      <div class="col-md-4">
                                          <ul class="general_info">
                                          <?php for ($maison_j = 0; $maison_j < ceil($maison_total/$maison_i); $maison_j++, $maison_p++){ ?>
                                              <li><i class="<?php echo $maison_features[$maison_p]['icon'] ?>"></i><?php echo $maison_features[$maison_p]['description'] ?></li>
                                          <?php } ?>
                                          </ul>
                                      </div>
                                  <?php } ?>
                                  </div>
                              </div>
                              <div class="col-md-6">
                                  <?php the_field('details_text'); ?>
                              </div>
                          </div>    
                        
                          <!-- Divisor-->
                          <div class="divisor margins">
                              <div class="circle_left"></div>
                              <div class="circle_right"></div>
                          </div>
                          <!-- End Divisor-->
                        
                         <div class="row">
                          <div class="col-md-12">
                            <div class="map_area">
                             <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
                             <?php 
                              
                              $maison_location = get_field('map');
                               
                              if( !empty($maison_location) ){
                              ?>
                              <div class="acf-map">
                                  <div class="marker" data-lat="<?php echo $maison_location['lat']; ?>" data-lng="<?php echo $maison_location['lng']; ?>"></div>
                              </div>
                              <?php } ?>
                              </div>
                            </div>
                        </div>
                      </div>
                      <!--End Tab1 Genral info-->      
                    
                      <?php
                       $maison_oagent = get_field('agent');
                       if($maison_oagent !== false){
                          $maison_agent = get_fields($maison_oagent->ID);
                      ?>
                      <!--Tab2 Contact Agent-->      
                      <div id="tab2" class="tab_content">                                                             
                         <div class="row">
                              <div class="col-md-7">
                                  <h4><?php echo of_get_option('title_form_agent'); ?></h4>
                                  <form id="form"   action="<?php echo get_template_directory_uri(); ?>/js/agent-contact/send_mail.php">
                                      <div class="row">
                                          <div class="col-md-6">
                                              <input type="text" placeholder="<?php echo of_get_option('form_agent_placeholder_name'); ?>" name="Name" required >
                                          </div>
                                          <div class="col-md-6">
                                              <input type="email" placeholder="<?php echo of_get_option('form_agent_placeholder_email'); ?>"  name="Email" required >
                                          </div>
                                      </div>
                                      <textarea placeholder="<?php echo of_get_option('form_agent_placeholder_message'); ?>" name="message"></textarea>
                                    
                                      <input type="hidden" name="from" value="<?php echo $maison_agent['mail'];?>">
                                      <input type="hidden" name="location" value="<?php echo the_field('location');?>">
                                      <input class="button" type="submit" value="<?php echo of_get_option('form_agent_button'); ?>" name="Submit" >
                                  </form>  
                                  <div class="result"></div>
                              </div>
                              <div class="col-md-5">
                                   <div class="row item_agent">
                                      <div class="col-md-6 image_agent">
                                          <img src="<?php echo $maison_agent['image'] ?>" alt="">
                                      </div>
                                      <div class="col-md-6 info_agent">
                                          <h5><?php echo $maison_oagent->post_title ?></h5>
                                          <ul>
                                              <?php 
                                                  $maison_datas = ($maison_agent['data'] !== false && $maison_agent['data'] !== null)?$maison_agent['data']:array();                                               
                                                  foreach($maison_datas as $maison_data){
                                              ?>
                                              <li><i class="<?php echo $maison_data['icon'] ?>"></i><a href="<?php echo $maison_data['link'] ?>"><?php echo $maison_data['text'] ?></a></li>
                                              <?php } ?>
                                          </ul>                                        
                                      </div>
                                   </div>
                                  <?php echo $maison_agent['description'] ?>
                              </div>
                         </div>        
                      </div>
                      <!--End Tab2 Contact Agent-->      
                      <?php
                           }
                      ?>
                      <!--Tab3 Map-->  
            
            
                      <!--Tab3 commnets-->      
                      <div id="tab3" class="tab_content">
                        <?php
                          comments_open(get_the_ID());
                          comments_template('',true);
                          ?>
                      </div>
                      <!--End Tab3 commnets--> 
  
                </div> 
								<!--END CONTAINER TABS-->		
						</div> 
					</div>
            
			<div class="row paddings">
             <div class="col-md-12">
                 <!-- Content Carousel Properties -->
                 <div class="content-carousel">
                    
                   <!-- Title-->
                   <div class="titles">
                     <span><?php echo of_get_option('subtitle_carousel_single'); ?></span>
                     <br>
                     <h1><?php echo of_get_option('title_carousel_single'); ?></h1>
                   </div>
                   <!-- End Title-->
                   
                  <?php
                  $maison_args = array();
                  $maison_args=array(
                    'post_type' => 'property',
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                  );
                  $maison_my_query = null;
                  $maison_my_query = new WP_Query($maison_args);
                  $maison_property = array();
                  
                  while ($maison_my_query->have_posts()) {
                      $maison_my_query->the_post();
                      $maison_property[] = array(
                          'ptitle' => get_the_title(),
                          'image' => get_field('images'),
                          'type' => get_field('type'),
                          'location' => get_field('location'),
                          'price' => get_field('price_unit').get_field('price'),
                          'permalink' => get_permalink(get_the_ID()),
                      );
                  }     
                  ?>
                   <!-- Carousel Properties -->
                   <div id="properties-carousel" class="properties-carousel">
                        <?php
                         foreach($maison_property as $maison_value){
                        ?>
                            <!-- Item Property-->
                            <div class="item_property">
                                <div class="head_property">
                                  <a href="<?php echo $maison_value['permalink']?>">
                                    <div class="title <?php echo $maison_value['type']?>"></div>
                                    <img src="<?php echo ($maison_value['image'] !== '')?$maison_value['image'][0]['url']:'' ?>" alt="Image">
                                    <h5><?php echo $maison_value['ptitle']?></h5>
                                  </a>
                                </div>                        
                                <div class="info_property">                                  
                                    <ul>
                                        <li><strong><?php echo of_get_option('title_place_carousel'); ?> </strong><span><?php echo $maison_value['location']?></span></li>
                                        <li><strong><?php echo of_get_option('title_price_carousel'); ?></strong><span><?php echo $maison_value['price']?></span></li>
                                    </ul>                                 
                                </div>
                             </div>
                             <!-- Item Property-->
                        <?php
                         }
                        ?>
                	</div>
		             <!-- End Carousel Properties -->
              </div>
          </div>
 
		</div>
</div>
<?php
     get_footer();
 ?>