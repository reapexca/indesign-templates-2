<?php
    $maison_other = array();
    $maison_pages = array();
    $maison_string = '';
    $maison_string = substr(get_post_meta( get_the_ID(), 'custom-zones-actives', true ),1);
    if(function_exists('get_field')){
        foreach(explode('|',$maison_string) as $maison_custom){
            $maison_page = substr($maison_custom,strpos($maison_custom,'acf_')+4);  
            if(get_field('rpt-'.$maison_page)!==false) {
                if($maison_page == 'select-plan') {    
                    foreach(get_field('rpt-'.$maison_page) as $maison_key){
                        $maison_pages[] = array(
                            'custom' => 'plan-zone',
                            'rpt' => $maison_key,
                            'weight' => $maison_key['weight_'.$maison_page],
                            'cate' => $maison_key['select_plans']
                        );
                    }
                }else{
                    foreach(get_field('rpt-'.$maison_page) as $maison_key){
                        $maison_pages[] = array(
                            'custom' => $maison_page,
                            'rpt' => $maison_key,
                          	'style_back' => $maison_key['style_back'],
                            'color' => $maison_key['color'],
                            //'cl_skin_base' => $maison_key['cl_skin_base'],
                          	'media_file' => $maison_key['media_file'],
                            //'parallax' => $maison_key['parallax'],
                            'weight' => $maison_key['weight_'.$maison_page]
                        );
                    }
                }
            }else{            
                $maison_other[] = $maison_page;
            }
        }
        function cmp($maison_a, $maison_b) {
            if ($maison_a['weight'] == $maison_b['weight']) {
                return 0;
            }
            return ($maison_a['weight'] < $maison_b['weight']) ? -1 : 1;
        };
        uasort($maison_pages, 'cmp');             
    }
    
    get_header(); 
        
        $maison_post = get_post();
        if(!empty($maison_post->post_content)){
            $maison_explo = explode('<!--more-->', $maison_post->post_content);
            $maison_content = '';//array_shift($studio_explo);
            foreach($maison_explo as $t){$maison_content .= $t;}
          				//Section Area
          	echo '<section class="section_area paddings">
                        <div class="container">
                            <div class="row">
																<div class="col-md-12">';
 	                           				 echo apply_filters('the_content', $maison_content); 
            echo '							</div>
														</div>
												</div>
									</section>';
          				//End Section Area
        }
        foreach($maison_pages as $maison_value){
          
           if($maison_value['style_back'] == 'video') { 
            	$maison_overflow_video = 'overflow_video';   		
           }else{ 
            	echo $maison_overflow_video = '';
           }    
          
           //Section Area
           echo '<section class="section_area '.$maison_overflow_video.'">';
          				if($maison_value['style_back'] == 'parallax') { 
                      echo ($maison_value['style_back'] == 'parallax')?'
       								<div class="bg_parallax" style="background-position: 50% 120px; background-image: url(\''.$maison_value['media_file'].'\');"></div>':'';
                   }
                  if($maison_value['style_back'] == 'video') { 
                    echo ($maison_value['style_back'] == 'video')?'
                      <video class="bg_section_video" preload="auto" autoplay="autoplay" loop muted>                        
                      			<source src="'.$maison_value['media_file'].'" type="video/mp4">
                      </video>':'';
                  }
                  $maison_color = '';
                  if($maison_value['style_back'] == 'parallax' || $maison_value['style_back'] == 'video'){
                    $maison_color = 'opacy_bg';
                  }
                  else if($maison_value['style_back'] == 'cl_skin_base'){
                    $maison_color = 'skin_base';
                  }
							
          	echo '<div class="'.$maison_color.' paddings" '; echo ($maison_value['style_back'] == 'color')?'style="background-color:'.$maison_value['color'].';">':'>';
          
             				include (dirname( __FILE__ ) .'/inc/custom-zones/zones-code/'.$maison_value['custom'].'.php'); 
           
          	echo '</div>
				</section>';//End Section Area
        }
    get_footer();