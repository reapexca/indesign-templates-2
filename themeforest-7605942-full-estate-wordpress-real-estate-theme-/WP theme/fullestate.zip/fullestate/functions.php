<?php
if (!isset($_SESSION))
    session_start();     
/*
* Loads the Options Panel
* If you're loading from a child theme use stylesheet_directory
* instead of template_directory
*/
add_action( 'after_setup_theme', 'maison_theme_setup' );

function maison_theme_setup()
{
    global $content_width;
    /* Set the $content_width for things such as video embeds. */
    if ( !isset( $content_width ) )
    $content_width = 900;
			
    /* Add theme support for automatic feed links. */
    add_theme_support( 'automatic-feed-links' );

    /* Add theme support for post thumbnails (featured images).*/
		add_theme_support( 'post-thumbnails' );

    /* Add your sidebars function to the 'widgets_init' action hook. */
		add_action( 'widgets_init', 'register_sidebars' );

    /* Load JavaScript files on the 'wp_enqueue_scripts' action hook. */
		add_action('wp_enqueue_scripts', 'maison_load_scripts');

    /* Load Style files on the 'wp_enqueue_style' action hook. */
		add_action( 'wp_enqueue_scripts', 'maison_load_styles' );
    
	  if(function_exists('of_get_option')){
			 add_action( 'wp_loaded', 'maison_config_styles' );
    }
  
    /* Load Favicon*/
		add_action( 'admin_head', 'maison_favicon' );
		add_action('wp_head', 'maison_favicon');

    /* Load Wordpress Logo to login page*/
		add_action('login_head', 'wp_login_mod'); 
    
  	/* post-formats*/
    add_theme_support( 'post-formats', array(
         'gallery', 'link', 'image', 'quote', 'audio', 'video',
    ));
}

if ( !defined( 'PRESSCORE_PLUGINS_DIR' ) ) {
    define( 'PRESSCORE_PLUGINS_DIR', get_template_directory_uri() . '/inc/plugins/' );
    require_once dirname( __FILE__ ) . '/inc/extensions/class-tgm-plugin-activation.php';
}
if ( !function_exists( '__construct' ) ) {
    define( 'CUSTOM_FIELD_DIRECTORY_LOCATION', get_template_directory_uri() . '/inc/acf-location-field/' );
    require_once dirname( __FILE__ ) . '/inc/acf-location-field/location-field.php';
}
if ( !function_exists( '__construct' ) ) {
    define( 'CUSTOM_FIELD_DIRECTORY_REPEATER', get_template_directory_uri() . '/inc/acf-repeater/' );
    require_once dirname( __FILE__ ) . '/inc/acf-repeater/acf-repeater.php';
}
if ( !function_exists( '__construct' ) ) {
    define( 'CUSTOM_FIELD_DIRECTORY_GALERY', get_template_directory_uri() . '/inc/acf-gallery/' );
    require_once dirname( __FILE__ ) . '/inc/acf-gallery/acf-gallery.php';
}                                                                         
if ( !function_exists( '__construct' ) ) {
    define( 'CUSTOM_FIELD_DIRECTORY_ICON', get_template_directory_uri() . '/inc/acf-gallery/' );
    require_once dirname( __FILE__ ) . '/inc/acf-icon/acf-icon.php';    
}
if ( !function_exists( '__construct' ) ) {
    require_once dirname( __FILE__ ) . '/inc/custom-zones/include_custom.php';
    require_once dirname( __FILE__ ) . '/inc/custom-zones/zones.php';
    //EXTRA FUNCTIONS
    require_once dirname( __FILE__ ) . '/inc/extra-codes/extra-functions.php';
    require_once dirname( __FILE__ ) . '/inc/extra-codes/add-post_types.php';
}      

/*------------------------------------------------------------*/
/*   Styles
/*------------------------------------------------------------*/
if( !function_exists( 'maison_load_styles' ) ) {
  function maison_load_styles(){
      global $wp_styles;

      if(!is_admin()){
        wp_enqueue_style( 'maison_style', get_stylesheet_uri() );
      }
      wp_enqueue_style('style_fs', get_template_directory_uri(). '/css/style.css', array());          
      
      wp_enqueue_style( 'load-gm', get_template_directory_uri() . '/inc/acf-location-field/load-gm.css', array());  
      
      if(function_exists('of_get_option')){
        wp_enqueue_style( 'theme-color', get_template_directory_uri() . '/css/skins/'.of_get_option('skin_style').'/'.of_get_option('skin_style').'.css', array());  
      }else{
        wp_enqueue_style( 'theme-color', get_template_directory_uri() . '/css/skins/red/red.css', array());  
      }
      wp_enqueue_style( 'iconf-font-awesome-styles', get_template_directory_uri() . '/inc/acf-icon/assets/css/font-awesome.css', array());  
      wp_enqueue_style( 'iconf-font-awesome-corp-styles', get_template_directory_uri() . '/inc/acf-icon/assets/css/font-awesome-corp.css', array());
      wp_enqueue_style( 'iconf-font-awesome-ext-styles', get_template_directory_uri() . '/inc/acf-icon/assets/css/font-awesome-ext.css', array());
      wp_enqueue_style( 'iconf-font-awesome-social-styles', get_template_directory_uri() . '/inc/acf-icon/assets/css/font-awesome-social.css', array());
      wp_enqueue_style( 'iconf-font-awesome-more-ie7', get_template_directory_uri() . '/inc/acf-icon/assets/css/font-awesome-more-ie7.min.css', array()); 
    }
}

/*------------------------------------------------------------*/
/*   Scripts
/*------------------------------------------------------------*/
if( !function_exists( 'maison_load_scripts' ) ) {
  function maison_load_scripts(){
    wp_enqueue_script('tinynav',get_template_directory_uri().'/js/nav/tinynav.js', array('jquery'),false, true);
    wp_enqueue_script('superfish',get_template_directory_uri().'/js/nav/superfish.js', array('jquery'),false, true);
    wp_enqueue_script('hoverIntent',get_template_directory_uri().'/js/nav/hoverIntent.js', array('jquery'),false, true);
    wp_enqueue_script('content-panel-switcher',get_template_directory_uri().'/js/efect_switcher/jquery.content-panel-switcher.js', array('jquery'),false, true);
    wp_enqueue_script('toptop', get_template_directory_uri().'/js/totop/jquery.ui.totop.js',array('jquery'), false, true);
    wp_enqueue_script('camera', get_template_directory_uri().'/js/slide/camera.js', array('jquery'), false, true);
    wp_enqueue_script('jquery.easing', get_template_directory_uri().'/js/slide/jquery.easing.1.3.min.js', array('jquery'), false, true);
    wp_enqueue_script('bootstrap',get_template_directory_uri().'/js/bootstrap/bootstrap.min.js', array('jquery'),false, true);
    wp_enqueue_script( 'load-gm',get_template_directory_uri() . '/inc/acf-location-field/js/load-gm.js', array( 'jquery' ), false, true); 
    wp_enqueue_script( 'carousel',get_template_directory_uri() . '/js/owlcarousel/owl.carousel.js', array( 'jquery' ), false, true); 
    wp_enqueue_script('parallax1', get_template_directory_uri().'/js/parallax/jquery.inview.js',array('jquery'), false, true);
    wp_enqueue_script('parallax2', get_template_directory_uri().'/js/parallax/nbw-parallax.js',array('jquery'), false, true);
    wp_enqueue_script('styleswitcher', get_template_directory_uri().'/js/theme-options/theme-options.js', array('jquery'), false, true);
    wp_enqueue_script('cookies', get_template_directory_uri().'/js/theme-options/jquery.cookies.js', array('jquery'), false, true);
    wp_enqueue_script( 'main',get_template_directory_uri() . '/js/main.js', array( 'jquery' ), false, true);    
  }
}

function wd_single_scripts() {
   if(is_singular() || is_page()){
   wp_enqueue_script( 'comment-reply' );
   }
}  

/*------------------------------------------------------------*/
/*   Register Menus WP4.0+
/*------------------------------------------------------------*/
if ( function_exists( 'register_nav_menus' ) )
{
  register_nav_menus(
    array(
      'Main' =>( 'Main Menu' ),
    )
  );
}

/*------------------------------------------------------------*/
/*   Sidenar Function
/*------------------------------------------------------------*/
if(function_exists('register_sidebar')) {
    register_sidebar(array(
      'name' => 'Primary',
      'id'   => 'primary',
      'description'   => 'These are widgets for the sidebar.',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget'  => '</div>',
      'before_title'  => '<h2>',
      'after_title'   => '</h2>'
    ));
    register_sidebar(array(
      'name' => 'Newsletter',
      'id'   => 'newsletter',
      'description'   => 'These are widgets for the newsletter.',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget'  => '</div>',
      'before_title'  => '<h2>',
      'after_title'   => '</h2>'
    ));
    register_sidebar(array(
      'name' => 'Filter',
      'id'   => 'filter',
      'description'   => 'These are widgets for the Widgets Filters.',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget'  => '</div>',
      'before_title'  => '<h2>',
      'after_title'   => '</h2>'
    ));

    register_sidebar(array(
      'name' => 'Filter1',
      'id'   => 'filter1',
      'description'   => 'These are widgets for the Shortcode Filters.',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget'  => '</div>',
      'before_title'  => '<h2>',
      'after_title'   => '</h2>'
    ));
    register_sidebar(array(
      'name' => 'Filter2',
      'id'   => 'filter2',
      'description'   => 'These are widgets for the Shortcode Filters.',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget'  => '</div>',
      'before_title'  => '<h2>',
      'after_title'   => '</h2>'
    ));
    register_sidebar(array(
      'name' => 'Filter3',
      'id'   => 'filter3',
      'description'   => 'These are widgets for the Shortcode Filters.',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget'  => '</div>',
      'before_title'  => '<h2>',
      'after_title'   => '</h2>'
    ));
}

/*------------------------------------------------------------*/
/*   Favicon Function
/*------------------------------------------------------------*/
function maison_favicon() {
     $full_estate_favicon = (function_exists('of_get_option'))?of_get_option('favicon'):get_template_directory_uri().'/img/icons/favicon.ico';
     echo '<link rel="Shortcut Icon" type="image/x-icon" href="'.$full_estate_favicon.'" />';
}

/*------------------------------------------------------------*/
/*   Logo Login Function
/*------------------------------------------------------------*/
function wp_login_mod() {
    if(function_exists('of_get_option'))
	    if(of_get_option('login')){
		    echo '<style type="text/css">
			    #login h1 a { background-size: 100% auto; height: 100px; width: 100%; background-image:url('.of_get_option('login').'); }
		    </style>';
		    }else{
		    echo '<style type="text/css">#login h1 a { background-size: 100% auto; height: auto; margin-bottom: -39px; width: 100%; background-image: url("'.get_template_directory_uri().'/img/wp_logo.png"); } </style>'; 
	    }else
      echo '<style type="text/css">#login h1 a { background-size: 100% auto; height: auto; margin-bottom: -39px; width: 100%; background-image: url("'.get_template_directory_uri().'/img/wp_logo.png"); } </style>'; 
}

/*------------------------------------------------------------*/
/*   breadcrumb Function
/*------------------------------------------------------------*/
function the_breadcrumb() {
    if (!is_home()) {
      echo '<span class="removed_link" title="&#039;;
      echo get_option(&#039;home&#039;);
            echo &#039;">';
      bloginfo('name');
      echo "</span>";
      if (is_category() || is_single()) {
        the_category('title_li=');
        if (is_single()) {
          echo " ";
          the_title();
        }
      } elseif (is_page()) {
        echo the_title();
      }
    }
}

/*------------------------------------------------------------*/
/*   woocommerce Function
/*------------------------------------------------------------*/
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10);

add_action('woocommerce_before_main_content', 'my_theme_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'my_theme_wrapper_end', 10);

function my_theme_wrapper_start() {
  echo '<section class="container woocommerce_styles">
					<div class="row">
							<div class="col-md-12">';
}
function my_theme_wrapper_end() {
  echo '</div></div></section>';
}

add_theme_support( 'woocommerce' );