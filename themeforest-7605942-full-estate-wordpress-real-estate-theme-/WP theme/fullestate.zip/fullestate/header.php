<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  	<meta charset="<?php bloginfo( 'charset' ); ?>" />
    <title>
    <?php wp_title( '|', true, 'right' );?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <?php wp_head(); 
        global $maison_page, $maison_paged;
    ?>
</head>
             
	<body <?php body_class();
          if(function_exists('of_get_option')){
            $maison_style = '';
            if(of_get_option('style_layout') == 2 || of_get_option('style_layout') == 3 || of_get_option('style_layout') == 4){
              if(of_get_option('layout_style')=='1'){
              $maison_style = ' style="background-color: '.of_get_option('layout_bg_color').'"';
            }else{
                $maison_style = ' style="background-image: url('.get_template_directory_uri().'/img/backs/bg'.of_get_option('layout_bg').'.png)"';
            	}
            }
            echo $maison_style;
          }
        ?>>
    
    <?php
        $maison_layout = '';
        global $maison_page_template;
        $maison_page_template = (!is_404())?$post->post_name:'404';
        if(function_exists('of_get_option')){
            if(of_get_option('style_layout') == 2){
              $maison_layout = 'layout-semiboxed';
            }else
            if(of_get_option('style_layout') == 3){
              $maison_layout = 'layout-boxed';
            }else if(of_get_option('style_layout') == 4){
              $maison_layout = 'layout-boxed-margin';
            }else{
              $maison_layout = 'layout-wide';    
            }
        }
      ?>
      
     <!-- layout-->
     <div id="layout" class="<?php echo $maison_layout; ?>"> 
       
        <?php 
           if (function_exists('of_get_option')){ 
             if (of_get_option('show_login')){ 
        ?> 
        <div class="jBar">
          <div class="container"> 
            <div class="row">  
              <form action="<?php echo get_home_url(); ?>/wp-login.php" method="POST">
                  <div class="col-md-2">
                    <h1><?php echo (function_exists('of_get_option'))?of_get_option('login_title'):'';?></h1>
                  </div>
					  
                  <div class="col-md-4">
                    <input type="text" name="log" placeholder="<?php echo (function_exists('of_get_option'))?of_get_option('user_title'):'';?>" required>
                  </div>
					  
                  <div class="col-md-3">
                    <input type="password" name="pwd" placeholder="<?php echo (function_exists('of_get_option'))?of_get_option('pass_title'):'';?>"> 
                  </div>
                  
                  <div class="col-md-3">
                    <input type="submit" name="wp-submit" class="botton" value="<?php echo (function_exists('of_get_option'))?of_get_option('login_btn1'):'';?>">
                    <span>Our</span>
                    <input type="button" class="botton" value="<?php echo (function_exists('of_get_option'))?of_get_option('login_btn2'):'';?>" onclick="window.location = '<?php echo get_home_url(); ?>/wp-login.php?action=register'">
                  </div>
					  
										<input type="hidden" name="redirect_to" value="<?php echo get_home_url(); ?>/" />
                  </form>    
                <p class="jTrigger downarrow"><?php echo of_get_option('btn_close_title');?></p>
              </div>
           </div>
        </div>
        <span class="jRibbon jTrigger up"><?php echo of_get_option('btn_open_title');?></span>
        <div class="line"></div>
        <!-- End Login Client -->
       
       <?php 
             }
           } 
        ?>

        <!-- Info Head -->
        <?php 
            $maison_finfo = (function_exists('of_get_option'))?of_get_option('show_first_info'):false;
            if($maison_finfo){
        ?>
        <section class="info_head">
           <div class="container">
             	<div class="row">
                	<div class="col-md-12">
                      <ul>
                        <?php
                          for($maison_i=1; $maison_i<=of_get_option('first_info_num'); $maison_i++){
                             echo '<li>
                                     <a href="'.of_get_option('info_link'.$maison_i).'">
                                        <i '.font_awesome_icon_style('info'.$maison_i).'></i>'.of_get_option('info_title'.$maison_i).'
                                     </a>
                                </li>';
                            }
                        ?>
                      </ul>
                    </div>
                </div>
          	</div>
        </section>
        <?php }?>
        <!-- Info Head -->

        <!-- Nav-->
        <nav>
           <div class="container">
                <div class="row">
                  	<!-- Logo-->
                    <div class="col-md-3">
                      	<div class="logo">
                          	<?php 
							$mainson_top_logo = (function_exists('of_get_option'))?of_get_option('logo_top_position'):'10px';
							?>
                        		<a <?php $maison_styles = (function_exists('of_get_option'))?of_get_option('typo_logo'):false; 
                        echo ($maison_styles !== false)?'style="color: '.$maison_styles['color'].'; font-style: '.$maison_styles['style'].'; font-family: '.$maison_styles['face'].'; font-size: '.$maison_styles['size'].';  top:'.$mainson_top_logo.';"':'' ?> 
 href="<?php echo get_site_url(); ?>">
                                
                                <?php
                                    $maison_slogo = (function_exists('of_get_option'))?of_get_option('style_logo'):'1';
                                    if($maison_slogo == '1'){
                                        echo (function_exists('of_get_option'))?of_get_option('text_logo'):'Full Estate';
                                    }else{
                                ?>
								
                                 <img src="<?php echo (function_exists('of_get_option'))?of_get_option('img_logo'):'img/logo.png';?>" alt="Logo" />
								 
                                <?php }?>
                         		</a>
                      	</div>
                    </div>
             				<!-- End Logo-->
										
             				<!-- Menu-->
             				<div class="col-md-9">
                    <?php 
                        wp_nav_menu(array(
                            'theme_location' => 'Main',
                            'menu_class' => 'sf-menu',
                            'menu_id' => 'menu',
                        )); 
                    ?>
                    </div>
			             <!-- End Menu-->
               </div>
           </div>
       </nav>
       <!-- End Nav-->

        <?php 
          if(have_posts()){
              $maison_id_post = get_the_ID();
              get_template_part('/inc/extra-codes/title-code'); 
              wp_reset_query();
          
          echo '<div class="content_info">';
                    
            				get_template_part('/inc/extra-codes/newsletter-code'); 
          
                    $maison_string = substr(get_post_meta( get_the_ID(), 'custom-zones-actives', true ),1);
                    if(stripos($maison_string,'acf_include-slider') !== false){
                        $maison_header_style = (function_exists('get_field'))?get_field('header_style'):'';
                        $maison_filter_style = (function_exists('get_field'))?get_field('filter_style'):'';
                        if($maison_header_style == 'sfilter' || $maison_header_style == 'mfilter' || $maison_header_style == 'ifilter'){
                            if ($maison_filter_style == 'filter3'){
                                echo '<div class="filter-bottom">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-12">';
                                                    $maison_filters = (function_exists('get_field'))?get_field('filter_tabs1'):'';
                                                    if($maison_filters !== false && $maison_filters !== ''){
                                                        if(!empty($maison_filters))
                                                            do_shortcode($maison_filters[0]['shortcode_filter']);    
                                                    }
                                      echo '		</div>  
                                            </div>
                                          </div>
                                      </div>';
                           }
                            wp_reset_query();
                        }
                    }
             }
     		?>