<?php
    get_header();
    global $maison_pos;
    $maison_pos = isset($_REQUEST['post_side'])?$_REQUEST['post_side']:3;
?>                  
<div class="container"> 
		<div class="row paddings">
        <?php
						get_template_part('content',get_post_format());     
        ?>
  	</div>
</div>
<?php
     get_footer();
 ?>