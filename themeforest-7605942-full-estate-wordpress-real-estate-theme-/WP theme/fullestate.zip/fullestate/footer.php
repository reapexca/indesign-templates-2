<?php
    echo '</div>';
    get_template_part('inc/extra-codes/sponsor-code');
    get_template_part('/inc/extra-codes/process-code');
		get_template_part('/inc/extra-codes/promotion-code');
    
    $maison_show_footer = (function_exists('of_get_option'))?of_get_option('show_footer'):true;
    $maison_show_fsec = (function_exists('of_get_option'))?of_get_option('show_footer_sec'):true;
    $maison_show_copyright = (function_exists('of_get_option'))?of_get_option('show_copyright'):true;
		$show_footer_sec_s1 = (function_exists('of_get_option'))?of_get_option('show_footer_sec_s1'):true;
		$show_footer_sec_s2 = (function_exists('of_get_option'))?of_get_option('show_footer_sec_s2'):true;
		$show_footer_sec_s3 = (function_exists('of_get_option'))?of_get_option('show_footer_sec_s3'):true;
		$show_footer_sec_s4 = (function_exists('of_get_option'))?of_get_option('show_footer_sec_s4'):true;
?>

<?php
		if($maison_show_footer){ 
?>
        <footer class="section_area paddings footer_medium">
            <div class="container">
                <div class="row">
                  <?php
                      if($show_footer_sec_s1){     
                  ?>
                   <div class="col-md-3">
                      <h3><?php echo (function_exists('of_get_option'))?of_get_option('footer_sec_s1_title'):'';?></h3>
                        <ul class="contact_footer">
                            <?php
                                $maison_num = (function_exists('of_get_option'))?of_get_option('footer_sec_s1_num'):1;
                                for($maison_i=1; $maison_i<=$maison_num; $maison_i++){     
                            ?>
                            <li>
                                <i <?php echo (function_exists('font_awesome_icon_style'))?font_awesome_icon_style('fcont'.$maison_i):'';?>></i>
                                <a href="<?php echo (function_exists('of_get_option'))?of_get_option('footer_sec_s1_info_link'.$maison_i):'';?>">
	                                <?php echo (function_exists('of_get_option'))?of_get_option('footer_sec_s1_info_v'.$maison_i):'';?>
                                </a>
                            </li>
                            <?php
                                }
                            ?>
                        </ul>         
                    </div>
                <?php
                    }     
                    if($show_footer_sec_s2){
                ?>
                    <div class="col-md-3 links">
                        <h3><?php echo (function_exists('of_get_option'))?of_get_option('footer_sec_s2_title'):'';?></h3>
                        <ul>
                            <?php
                                $maison_num = (function_exists('of_get_option'))?of_get_option('footer_sec_s2_num'):1;
                                for($maison_i=1; $maison_i<=$maison_num; $maison_i++){     
                            ?>
                            <li>
                                <a href="<?php echo (function_exists('of_get_option'))?of_get_option('footer_sec_s2_info_link'.$maison_i):'';?>">
                                <?php echo (function_exists('of_get_option'))?of_get_option('footer_sec_s2_info_v'.$maison_i):'';?>
                                </a>
                            </li>
                            <?php
                                }
                            ?>
                        </ul>
                    </div>
                 <?php
                    }     
                    if($show_footer_sec_s3){     
                 ?>
                    <!-- Tags -->
                    <div class="col-md-3 padding_items">
                        <?php
                        if(function_exists('of_get_option')){
                            echo '<h3>Tag Cloud</h3>';
                        }
                        ?>
                        <ul class="tags">
                        <?php
                            if(function_exists('of_get_option')){
                            $maison_tag_num = (of_get_option('tag_num') !== false) ? of_get_option('tag_num') : '3';
                            foreach(get_tags(array('number' => $maison_tag_num)) as $maison_key){
                        ?>
                        <li>
                            <a href="<?php echo get_term_link( intval($maison_key->term_id), $maison_key->taxonomy );?>">
                            <?php echo $maison_key->name?>
                            </a>
                        </li>
                        <?php
                            }
                            }
                         ?>
                        </ul>
                    </div>
                 <?php
                    }     
                    if($show_footer_sec_s4){     
                 ?>
                    <!-- Testimonials -->
                    <div class="col-md-3">
                         <ul class="testimonial-carousel">
                            <?php
                            if(function_exists('of_get_option')){
                                for($maison_i=1; $maison_i<=of_get_option('footer_sec_s4_num'); $maison_i++){     
                            ?>
                           		<!-- Item Testimonial -->
                              <li>
                                  <div class="testimonials">
                                      <p><?php echo of_get_option('footer_sec_s4_coment'.$maison_i);?></p>
                                       <span class="arrow_testimonials"></span>
                                   </div>        
                                   <h6 class="testimonial_autor"><?php echo of_get_option('footer_sec_s4_author'.$maison_i);?></h6> 
                              </li>
                              <!-- Item Testimonial -->
                            <?php
                                }     
                            }
                            ?>
                          </ul>
                      </div>
                      <!-- End Testimonials -->
                 <?php
                    }     
                 ?>
                </div>
            </div>
        </footer>
	<?php
        }
        if($maison_show_copyright){
 	?>
        <footer class="section_area footer_down">
            <div class="container">
                <div class="row">
                   <div class="col-md-6">
                        <p>
                            <a href="<?php echo (function_exists('of_get_option'))?of_get_option('copyright_text_link'):'';?>">
                                <?php echo (function_exists('of_get_option'))?of_get_option('copyright_text'):'';?>
                            </a>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <ul class="social">
                            <?php
                            if(function_exists('of_get_option')){
                                for($maison_i=1; $maison_i<=of_get_option('copyright_text_number'); $maison_i++){    
                            ?>
                            <li data-toggle="tooltip" title data-original-title="<?php echo of_get_option('copy_text_link_title'.$maison_i);?>">
                                <a href="<?php echo of_get_option('copy_text_link_link'.$maison_i);?>">
                                    <i <?php echo font_awesome_icon_style('copy_ico'.$maison_i);?>></i>
                                </a>
                            </li>
                            <?php
                                }
                            }     
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </footer> 
    <?php
      }
      wp_footer();
    ?>
			</div>
    <!-- End layout-->
		
		<!-- Style Switcher Theme -->
		<?php  
				 if (function_exists('of_get_option')){ 
            if (of_get_option('show_style_switcher')){ 
							get_template_part('/inc/extra-codes/stylewitcher-options');  
						}
         }
		?>
		<!-- End Style Switcher Theme -->

  </body>
</html>