<?php
    $options[] = array(
        'name' => 'Process',
        'type' => 'heading',
				'std'  => 'gear'
    );
    //PROCESS ZONE
    $options[] = array(
        'name' => 'Process Zone Configuration',
        'type' => 'info'
    );
    $options[] = array(
        'id' => 'show_pub',
        'desc' => 'Show Publicity Zone',
        'std' => 0,
        'type' => 'checkbox',
    );
    $options[] = array(
        'id' => 'pub_num',
        'desc' => 'Number of Publicity to add',
        'std' => '1',
        'type' => 'text',
        'class' => 'mini'
    );
    if(of_get_option('pub_num')?$cant=of_get_option('pub_num'):$cant=1);
    for($i=1; $i<=$cant; $i++){
        $options[] = array(
            'name' => 'Publicity '.$i,
            'type' => 'info'
        );
           $options[] = array(
                'id' => 'pub_title'.$i,
                'desc' => 'Publicity Title',
                'std' => 'Publicity Name',
                'type' => 'text',
            ); 
            $options[] = array(
                'id' => 'pub_link'.$i,
                'desc' => 'Publicity Link',
                'type' => 'text',
            ); 
            foreach(font_awesome_icon('pub_ico'.$i) as $val){
                        $options[] = $val;
            } 
    }

	    $options[] = array(
            'name' => 'Templates to show Process Zone:',
            'type' => 'info'
	    );
        $pages = array();
        foreach(get_pages() as $titles){
            $tit = $titles->post_name;
            $pages[$tit] = $titles->post_title;
        }
        $pages['index'] = 'Index';
        $pages['single'] = 'Single Post';
        $pages['single-property'] = 'Single Property';
        $pages['404'] = '404 page';
        $options[] = array(
            'id' => 'pub_template',
            'options' => $pages,
            'type' => 'multicheck',
        );
?>