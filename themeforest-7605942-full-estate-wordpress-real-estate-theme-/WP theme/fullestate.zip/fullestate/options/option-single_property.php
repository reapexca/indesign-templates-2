<?php
    $options[] = array(
        'name' => 'Single Property',
        'type' => 'heading',
		'std'  => 'gear'
    );
    $options[] = array(
        'id' => 'single_property_shortcode',
        'desc' => 'Filter Shortcode',
        'type' => 'text',
    );
