<?php
  $options[] = array(
        'name' => 'Fonts',
        'type' => 'heading',
        'std' => 'edit'
  );  
    //TYPOGRAPHY STYLE
    $options[] = array(
        'id' => 'general_skin_color_ch',
        'desc' => 'Enable Typography configuration',
        'type' => 'checkbox'
    );
    for($i=1; $i<=6; $i++){
        $options[] = array(
            'name' => 'H'.$i.' Typography Style',
            'type' => 'info'
        );
        $options[] = array(
            'id' => 'general_color_h'.$i.'_ch',
            'desc' => 'Enable style color configuration',
            'type' => 'checkbox'
        );
        $options[] = array(
            'name' => 'Define <h'.$i.'> Typography',
            'type' => 'info'
        );
        $options[] = array(
            'id' => 'general_color_h'.$i,
            'std' => array( 'size' => '36px', 'face' => 'Open Sans', 'style'=>'normal', 'color'=> '#080808'),
            'type' => 'typography'
        );  
    }
    //H1 SMALL
    $options[] = array(
        'name' => 'Small Typography Style',
        'type' => 'info'
    );
        $options[] = array(
            'id' => 'general_color_h1s_ch',
            'desc' => 'Enable style color configuration',
            'type' => 'checkbox'
        );
        $options[] = array(
            'name' => 'Define <small> Typography',
            'type' => 'info'
        );
        $options[] = array(
            'id' => 'general_color_h1s',
            'std' => array( 'size' => '36px', 'face' => 'Open Sans', 'style'=>'normal', 'color'=> '#00bc96'),
            'type' => 'typography'
        );       
    //<a>
    $options[] = array(
        'name' => 'A Typography Style',
        'type' => 'info'
    );
        $options[] = array(
            'id' => 'general_color_a_ch',
            'desc' => 'Enable style color configuration',
            'type' => 'checkbox'
        );
        $options[] = array(
            'name' => 'Define <a> Typography',
            'type' => 'info'
        );
        $options[] = array(
            'id' => 'general_color_a',
            'std' => array( 'size' => '14px', 'face' => 'Open Sans', 'style'=>'normal', 'color'=> '#5c5c5c'),
            'type' => 'typography'
        );      
    //<p>
    $options[] = array(
        'name' => 'P Typography Style',
        'type' => 'info'
    );
        $options[] = array(
            'id' => 'general_color_p_ch',
            'desc' => 'Enable style color configuration',
            'type' => 'checkbox'
        );
        $options[] = array(
            'name' => 'Define <p> Typography',
            'type' => 'info'
        );
        $options[] = array(
            'id' => 'general_color_p',
            'std' => array( 'size' => '14px', 'face' => 'Open Sans', 'style'=>'normal', 'color'=> '#5c5c5c'),
            'type' => 'typography'
        );    
    //BUTTON
    $options[] = array(
        'name' => 'Button Background Typography Style',
        'type' => 'info'
    );
        $options[] = array(
            'id' => 'general_color_btn_ch',
            'desc' => 'Enable style color configuration',
            'type' => 'checkbox'
        );
        $options[] = array(
            'name' => 'Define Button Typography',
            'type' => 'info'
        );
        $options[] = array(
        'id' => 'general_color_btn',
        'std' => array( 'size' => '14px', 'face' => 'Open Sans', 'style'=>'normal', 'color'=> '#fff'),
        'type' => 'typography'
    );