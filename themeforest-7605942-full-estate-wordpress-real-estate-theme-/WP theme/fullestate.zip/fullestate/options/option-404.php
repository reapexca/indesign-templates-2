<?php
    $options[] = array(
        'name' => '404',
        'type' => 'heading',
				'std' => 'remove'
		);
    $options[] = array(
        'name' => '404 Banner Configuration',
        'type' => 'info'
    );
    $options[] = array(
        'id' => '404_ban_img',
		    'desc' => 'Banner Image',
        'type' => 'upload'
		);
    $options[] = array(
        'name' => '404 Content Configuration',
        'type' => 'info'
    );
    $options[] = array(
        'id' => '404_title',
        'desc' => 'Title',
        'std' => '404',
        'type' => 'text'
    );
		$options[] = array(
        'id' => '404_explain',
        'desc' => 'Explain',
        'std' => '404',
       	'type' => 'textarea'
    );
    $options[] = array(
        'id' => '404_botton',
        'desc' => 'Button Title',
        'std' => '404',
        'type' => 'text'
     );