<?php
    $options[] = array(
        'name' => 'Sponsors',
        'type' => 'heading',
				'std'  => 'gear'
    );
    $options[] = array(
        'name' => 'Sponsor Zone Configuration',
        'type' => 'info',
        'class' => 'toggle-slide',
        'id' => 'sponsor'
    );
    $options[] = array(
        'id' => 'show_sponsor',
        'desc' => 'Show Sponsor Zone',
        'std' => 0,
        'type' => 'checkbox',
    );
    $options[] = array(
        'id' => 'sponsor_num',
        'desc' => 'Number of Sponsor to add',
        'std' => '1',
        'type' => 'text',
        'class' => 'mini'
    );
    if(of_get_option('sponsor_num')?$cant=of_get_option('sponsor_num'):$cant=1);
    for($i=1; $i<=$cant; $i++){
        $options[] = array(
            'name' => 'Sponsor '.$i,
            'type' => 'info',
            'class' => 'toggle-sponsor'
        );
           $options[] = array(
                'id' => 'sponsor_title'.$i,
                'desc' => 'Sponsor Title',
                'std' => 'Sponsor Name',
                'type' => 'text',
                'class' => 'toggle-sponsor'
            ); 
            $options[] = array(
                'id' => 'sponsor_link'.$i,
                'desc' => 'Sponsor Link',
                'type' => 'text',
                'class' => 'toggle-sponsor'
            ); 
            $options[] = array(
                'id' => 'sponsor_img'.$i,
                'type' => 'upload',
                'class' => 'toggle-sponsor'
            ); 
    }
    
    $options[] = array(
        'name' => 'Templates to show Sponsor Zone',
        'type' => 'info'
    );
        $pages = array();
        foreach(get_pages() as $titles){
            //$tit = strtolower(str_replace(' ','_',$titles->post_name));
            $tit = $titles->post_name;
            $pages[$tit] = $titles->post_title;
        }
        $pages['index'] = 'Index';
        $pages['single'] = 'Single Post';
        $pages['single-property'] = 'Single Property';
        $pages['404'] = '404 page';
        $options[] = array(
            'id' => 'sponsor_template',
            'options' => $pages,
            'type' => 'multicheck',
        );
