<?php
    $options[] = array(
        'name' => 'Header',
        'type' => 'heading',
		'std'  => 'cogs'
    );

		/*========  Login Header Form =============*/

		$options[] = array(
        'name' => 'Login Form Option',
        'type' => 'info',
    );
		 $options[] = array(
        'id' => 'show_login',
        'desc' => 'Show Configuration',
        'std' => 1,
        'type' => 'checkbox',
    );
    $options[] = array(
        'id' => 'btn_open_title',
        'desc' => 'Button Open Title',
        'std' => 'Login',
        'type' => 'text',
    );
    $options[] = array(
        'id' => 'btn_close_title',
        'desc' => 'Button Close Title',
        'std' => 'Close Login',
        'type' => 'text',
    );

		$options[] = array(
        'name' => '',
        'type' => 'info',
    );

		 $options[] = array(
      'id' => 'user_title',
      'desc' => 'Placeholder Mail',
      'std' => 'demo@yourmail.com',
      'type' => 'text'
    );
		 $options[] = array(
      'id' => 'pass_title',
      'desc' => 'Placeholder Password',
      'std' => 'Your Password',
      'type' => 'text'
    );
    $options[] = array(
      'id' => 'login_title',
      'desc' => 'Title Zone',
      'std' => 'Login Area',
      'type' => 'text'
    );
    $options[] = array(
      'id' => 'login_btn1',
      'desc' => 'Button 1 Title',
      'std' => 'Sign in',
      'type' => 'text'
    );
    $options[] = array(
      'id' => 'login_btn2',
      'desc' => 'Button 2 Title',
      'std' => 'Register',
      'type' => 'text'
    );  
		
		$options[] = array(
        'name' => '',
        'type' => 'info',
    );
    $options[] = array(
        'name' => 'Header Information',
        'type' => 'info'
    );
    $options[] = array(
      'id' => 'show_first_info',
      'desc' => 'Show Style Configuration',
      'std' => 1,
      'type' => 'checkbox'
    );
    $options[] = array(
      'id' => 'first_info_num',
      'desc' => 'Number of information',
      'std' => '3',
      'type' => 'text',
      'class' => 'mini'
    );
    if(of_get_option('first_info_num')?$cant=of_get_option('first_info_num'):$cant=3);
    for($i=1; $i<=$cant; $i++){
      $options[] = array(
        'name' => 'Information '.$i,
        'type' => 'info'
      );
      $options[] = array(
        'id' => 'info_title'.$i,
        'desc' => 'Info Title',
        'std' => 'Info Head',
        'type' => 'text'
      );
      foreach(font_awesome_icon('info'.$i) as $val){
        $options[] = $val;
      }
      $options[] = array(
        'id' => 'info_link'.$i,
        'desc' => 'Info Link',
        'type' => 'text'
      );
    }
  	
		$options[] = array(
        'name' => '',
        'type' => 'info'
    );
    $options[] = array(
        'name' => 'Category Text Title',
        'type' => 'info'
    );
    $options[] = array(
      'id' => 'cat_text',
      'desc' => 'Category Title',
      'std' => 'Category Archive: ',
      'type' => 'text',
    );
    $options[] = array(
      'id' => 'cat_img',
      'desc' => 'Category Image Banner',
      'type' => 'upload',
    );
    $options[] = array(
        'name' => 'Tag Text Title',
        'type' => 'info'
    );
    $options[] = array(
      'id' => 'tag_text',
      'desc' => 'Tag Title',
      'std' => 'Tag Archive: ',
      'type' => 'text',
    );
    $options[] = array(
      'id' => 'tag_img',
      'desc' => 'Tag Image Banner',
      'type' => 'upload',
    );
    $options[] = array(
        'name' => 'Search Text Title',
        'type' => 'info'
    );
    $options[] = array(
      'id' => 's_text',
      'desc' => 'Search Title',
      'std' => 'Search Archive: ',
      'type' => 'text',
    );
    $options[] = array(
      'id' => 's_img',
      'desc' => 'Search Image Banner',
      'type' => 'upload',
    );
    $options[] = array(
        'name' => 'Archive Image',
        'type' => 'info'
    );
    $options[] = array(
      'id' => 'arch_img',
      'desc' => 'Archive Image Banner',
      'type' => 'upload',
    );