<?php
    $options[] = array(
        'name' => 'Appearance',
        'type' => 'heading',
    );
		
		//Logo Options
		 $options[] = array(
        'name' => 'Logo Configuration Zone',
        'type' => 'info'
    );
        $options[] = array(
            'id' => 'style_logo',
            'std' => '1',
            'options' => array(
                '1' => 'Text Logo',
                '2' => 'Image Logo'                     
            ),
            'type' => 'radio',
	          'std' => '1',
            'class' => 'side ft'
        );
        $options[] = array(
            'id' => 'text_logo',
            'desc' => 'Logo Text',
            'std' => 'Full Estate',
            'type' => 'text',
            'class' => 'ft1 fhide',
        );
        $options[] = array(
            'id' => 'img_logo',
            'desc' => 'Logo Image',
            'type' => 'upload',
            'class' => 'ft2 fhide',
        );
        $options[] = array(
            'id' => 'typo_logo',
            'desc' => 'Logo Typography',
            'std' => array( 'size' => '16px', 'face' => 'Open Sans', 'style'=>'normal', 'color'=> '#ffffff'),
            'type' => 'typography',
            'class' => 'ft1 fhide',
        );    
				$options[] = array(
            'id' => 'logo_top_position',
            'desc' => 'Logo Top Position',
            'std' => '10px',
            'type' => 'text',
        );
        $options[] = array(
            'name' => '',
            'type' => 'info'
        );

				//Favicon Options
        $options[] = array(
            'name' => 'Favicon',
            'type' => 'info'
        ); 
        $options[] = array(
          'id' => 'favicon',
          'type' => 'upload'
        );
				
				//Logo Login Options
        $options[] = array(
            'name' => 'Logo Login',
            'type' => 'info'
        ); 
        $options[] = array(
          'id' => 'login',
          'type' => 'upload'
        ); 
		
		//Skins Options
		$options[] = array(
      'name' => '',
      'type' => 'info'
    );
    $options[] = array(
        'name' => 'Skin Configuration Style',
        'type' => 'info',
    );
    $options[] = array(
      'id' => 'skin_style',
      'options' => array(
            'blue' => get_template_directory_uri().'/img/skins/blue.jpg',
            'cocoa' => get_template_directory_uri().'/img/skins/cocoa.jpg',
            'green' => get_template_directory_uri().'/img/skins/green.jpg',
            'orange' => get_template_directory_uri().'/img/skins/orange.jpg',
            'pink' => get_template_directory_uri().'/img/skins/pink.jpg',
            'purple' => get_template_directory_uri().'/img/skins/purple.jpg',
            'red' => get_template_directory_uri().'/img/skins/red.jpg',
            'yellow' => get_template_directory_uri().'/img/skins/yellow.jpg',
      ),
      'std' => 'red',
      'type' => 'images',
    );
        

    	//Layout Options
       $options[] = array(
            'name' => 'Layout Styles',
            'type' => 'info'
        );
            $backs = array(
                '0' => get_template_directory_uri().'/img/backs_mini/bg0.png',
	              '2' => get_template_directory_uri().'/img/backs_mini/bg2.png',
                '3' => get_template_directory_uri().'/img/backs_mini/bg3.png',
                '4' => get_template_directory_uri().'/img/backs_mini/bg4.png',
                '5' => get_template_directory_uri().'/img/backs_mini/bg5.png',
                '6' => get_template_directory_uri().'/img/backs_mini/bg6.png',
                '7' => get_template_directory_uri().'/img/backs_mini/bg7.png',
                '8' => get_template_directory_uri().'/img/backs_mini/bg8.png',
                '9' => get_template_directory_uri().'/img/backs_mini/bg9.png',
                '10' => get_template_directory_uri().'/img/backs_mini/bg10.png',
                '11' => get_template_directory_uri().'/img/backs_mini/bg11.png',
                '12' => get_template_directory_uri().'/img/backs_mini/bg12.png',
                '13' => get_template_directory_uri().'/img/backs_mini/bg12.png',
                '14' => get_template_directory_uri().'/img/backs_mini/bg14.png',
                '15' => get_template_directory_uri().'/img/backs_mini/bg15.png',
                '16' => get_template_directory_uri().'/img/backs_mini/bg16.png',
                '17' => get_template_directory_uri().'/img/backs_mini/bg17.png',
                '18' => get_template_directory_uri().'/img/backs_mini/bg18.png',
                '19' => get_template_directory_uri().'/img/backs_mini/bg19.png',
                '20' => get_template_directory_uri().'/img/backs_mini/bg20.png',
                '21' => get_template_directory_uri().'/img/backs_mini/bg21.png',
                '22' => get_template_directory_uri().'/img/backs_mini/bg22.png',
                '23' => get_template_directory_uri().'/img/backs_mini/bg23.png',
                '24' => get_template_directory_uri().'/img/backs_mini/bg24.png',
                '25' => get_template_directory_uri().'/img/backs_mini/bg25.png',
            );

            if(of_get_option('layout_bg_num')?$cant=of_get_option('layout_bg_num'):$cant=0);

            for($i=1; $i<=$cant; $i++){
                $backs[$i] = of_get_option('layout_bg_img'.$i);
            }
            $options[] = array(
                'id' => 'style_layout',
                'desc' => 'Select you Layout Style',
                'std' => '1',
                'options' => array(
                    '1' => 'Layout Wide',
                  	'2' => 'Layout SemiBoxed',
                    '3' => 'Layout Boxed',
                    '4' => 'Layout Boxed Margin',
                ),
                'type' => 'select',
                'class' => 'st'
            );
            $options[] = array(
                'id' => 'layout_style',
                'desc' => 'Layout Style Background',
                'std' => '1',
                'options' => array(
                    '1' => 'Color',
                    '2' => 'Image',
                ),
                'type' => 'radio',
                'class' => 'side ft st2 st3 st4 shide'
            );
            $options[] = array(
                'id' => 'layout_bg_color',
                'desc' => 'Color Background (only Semiboxed, Boxed And Boxed Margin Versions)',
                'type' => 'color',
                'class' => 'ft1 fhide shide',
            );
            $options[] = array(
              'id' => 'layout_bg',
              'desc' => 'Background (only Semiboxed, Boxed And Boxed Margin Versions)',
              'std' => '0',
              'options' => $backs,
              'type' => 'images',
              'class' => 'ft2 fhide shide',
            );

					
					/*========  Login Header Form =============*/
					 $options[] = array(
              'name' => '',
              'type' => 'info',
          );
          $options[] = array(
              'name' => 'style switcher Theme',
              'type' => 'info',
          );
           $options[] = array(
              'id' => 'show_style_switcher',
              'desc' => 'Show Configuration - style switcher',
              'std' => 1,
              'type' => 'checkbox',
          );