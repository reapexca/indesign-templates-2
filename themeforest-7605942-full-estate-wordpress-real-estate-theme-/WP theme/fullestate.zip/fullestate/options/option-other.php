<?php
    $options[] = array(
        'name' => 'Other Options',
        'type' => 'heading',
				'std'  => 'gear'
    );
		// Bar Filter Property
		$options[] = array(
        'name' => 'Bar - Filter, Property',
        'type' => 'info',
    );
		$options[] = array(
      'id' => 'filter_title',
      'desc' => 'Filter Title',
      'std' => 'Filter',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'filter_all',
      'desc' => 'All Items Title',
      'std' => 'All',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'filter_sale',
      'desc' => 'Filter Sale Title',
      'std' => 'For Sale',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'filter_rent',
      'desc' => 'Title Rent Title',
      'std' => 'For Rent',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'filter_offer',
      'desc' => 'Filter Offer Title',
      'std' => 'To Offer',
      'type' => 'text'
    );

		// Bar Filter Property
		$options[] = array(
       'name' => 'Bar - Filter, Order Property',
       'type' => 'info',
    );
		$options[] = array(
      'id' => 'order_bar',
      'desc' => 'Order Title Title',
      'std' => 'Order BY',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'order_recent',
      'desc' => 'Date Published Order Title',
      'std' => 'Recent ads',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'order_prices',
      'desc' => 'Price Order Title',
      'std' => 'Price',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'sort_a',
      'desc' => 'Ascending Order Title (Tooltip)',
      'std' => 'Sort Ascending',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'sort_d',
      'desc' => 'Descending Order Title (Tooltip)',
      'std' => 'Sort Descending',
      'type' => 'text'
    );

		$options[] = array(
        'name' => 'Bar - Filter , Layout Property',
        'type' => 'info',
    );
		$options[] = array(
      'id' => 'grid_layout_bar',
      'desc' => 'Grid Layout Title (Tooltip)',
      'std' => 'Grid Layout',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'list_layout_bar',
      'desc' => 'List Layout Title (Tooltip)',
      'std' => 'List Layout',
      'type' => 'text'
    );


		// Description Sigle Property
		$options[] = array(
        'name' => 'DescriptionProperty',
        'type' => 'info',
    );
		$options[] = array(
      'id' => 'title_price_description',
      'desc' => 'Title Price',
      'std' => 'Price',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'title_location_description',
      'desc' => 'Title Location',
      'std' => 'Location',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'title_area_description',
      'desc' => 'Title Area',
      'std' => 'Area',
      'type' => 'text'
    );

		// Nav Tabs Sigle Property
		$options[] = array(
        'name' => '',
        'type' => 'info',
    );
		$options[] = array(
        'name' => 'Nav Tabs Single Property',
        'type' => 'info',
    );
		$options[] = array(
      'id' => 'tab_1_single',
      'desc' => 'Tab Details',
      'std' => 'More Details',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'tab_2_single',
      'desc' => 'Tab Agent',
      'std' => 'Contact Agent',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'tab_3_single',
      'desc' => 'Tab Comments',
      'std' => 'Comments',
      'type' => 'text'
    );

		// Title Form Agent Sigle Property
		$options[] = array(
        'name' => '',
        'type' => 'info',
    );
		$options[] = array(
        'name' => 'Form Agent - Single Property',
        'type' => 'info',
    );
		$options[] = array(
      'id' => 'title_form_agent',
      'desc' => 'Title Form - Agent',
      'std' => 'Contact Agent',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'form_agent_placeholder_name',
      'desc' => 'Placeholder Name',
      'std' => 'Your Name',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'form_agent_placeholder_email',
      'desc' => 'Placeholder Email',
      'std' => 'Your Email',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'form_agent_placeholder_message',
      'desc' => 'Placeholder Message',
      'std' => 'Your Message...',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'form_agent_button',
      'desc' => 'Title Button',
      'std' => 'Send Message',
      'type' => 'text'
    );
		
		// Carousels Sigle Property
		$options[] = array(
        'name' => '',
        'type' => 'info',
    );
		$options[] = array(
        'name' => 'Carousel Single Property',
        'type' => 'info',
    );
		$options[] = array(
      'id' => 'title_carousel_single',
      'desc' => 'Title Carousel',
      'std' => 'CAROUSEL PROPERTIES',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'subtitle_carousel_single',
      'desc' => 'Subtitle Carousel',
      'std' => 'RECENTS',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'title_place_carousel',
      'desc' => 'Title Place',
      'std' => 'Place',
      'type' => 'text'
    );
		$options[] = array(
      'id' => 'title_price_carousel',
      'desc' => 'Title Price',
      'std' => 'Price',
      'type' => 'text'
    );

		// Carousels Sigle Property
		$options[] = array(
        'name' => '',
        'type' => 'info',
    );
		$options[] = array(
        'name' => 'Blog Section',
        'type' => 'info',
    );
		$options[] = array(
      'id' => 'title_button_post',
      'desc' => 'Title Button Blog',
      'std' => 'Read More',
      'type' => 'text'
    );
?>