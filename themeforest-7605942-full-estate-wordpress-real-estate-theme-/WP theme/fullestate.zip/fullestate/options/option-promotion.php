<?php
    $options[] = array(
        'name' => 'Promotion',
        'type' => 'heading',
				'std' => 'arrow-down'
    );

    $options[] = array(
      'name' => 'Fisrt Zone Configuration',
      'type' => 'info'
    );                                                   
    $options[] = array(
      'id' => 'show_footer_first',
      'desc' => 'Show Style Configuration',
      'std' => 1,
      'type' => 'checkbox'
    );
    $options[] = array(
      'id' => 'footer_first_title',
      'desc' => 'Title',
      'std' => 'Get in touch',
      'type' => 'text'
    );
    $options[] = array(
      'id' => 'footer_first_desc',
      'desc' => 'Description',
      'std' => 'Lorem ipsum ea cum congue bonorum, pri no natum clita. His ne vide omnis forensibus. Eum cetero imperdiet et.!:',
      'type' => 'textarea'
    );
    $options[] = array(
      'id' => 'footer_first_btn',
      'desc' => 'Button Title',
      'std' => 'Demo',
      'type' => 'text'
    );
    $options[] = array(
      'id' => 'footer_first_btn_link',
      'desc' => 'Button Link',
      'type' => 'text'
    );

	$options[] = array(
        'name' => 'Templates to show Sponsor Zone',
        'type' => 'info'
    );
        $pages = array();
        foreach(get_pages() as $titles){
            $tit = $titles->post_name;
            $pages[$tit] = $titles->post_title;
        }
        $pages['index'] = 'Index';
        $pages['single'] = 'Single Post';
        $pages['single-property'] = 'Single Property';
        $pages['404'] = '404 page';
        $options[] = array(
            'id' => 'show_promotion_pages',
            'options' => $pages,
            'type' => 'multicheck',
        );
?>