<?php
    $options[] = array(
      'name' => 'Footer Options',
      'type' => 'heading',
			'std' => 'arrow-down'
    );
    $options[] = array(
      'id' => 'show_footer',
      'desc' => 'Show Footer Configuration',
      'std' => 1,
      'type' => 'checkbox'
    );
    
    // Contact Footer
		$options[] = array(
      'name' => '',
      'type' => 'info'
    );
    $options[] = array(
      'name' => 'Contact Footer Section',
      'type' => 'info'
    );
    $options[] = array(
      'id' => 'show_footer_sec_s1',
      'desc' => 'Show Contact Footer Section',
      'std' => 1,
      'type' => 'checkbox'
    );
    $options[] = array(
      'id' => 'footer_sec_s1_title',
      'desc' => 'Title',
      'std' => 'Contact Us',
      'type' => 'text'
    );
    $options[] = array(
      'id' => 'footer_sec_s1_num',
      'desc' => 'Number of Info',
      'std' => '3',
      'type' => 'text',
      'class' => 'mini'
    );
    if(of_get_option('footer_sec_s1_num') > 0? $cant_ = of_get_option('footer_sec_s1_num'):$cant_=3);
        for($i=1; $i<=$cant_; $i++){
          $options[] = array(
            'name' => 'Contact '.$i,
            'type' => 'info'
          );
          foreach(font_awesome_icon('fcont'.$i) as $val){
            $options[] = $val;
          }
          $options[] = array(
            'id' => 'footer_sec_s1_info_v'.$i,
            'desc' => 'Value',
            'std' => 'demo@iwthemes.com',
            'type' => 'text'
          );
          $options[] = array(
            'id' => 'footer_sec_s1_info_link'.$i,
            'desc' => 'Link Value',
            'type' => 'text'
          );
       }
			
			// Links Footer
      $options[] = array(
        'name' => '',
        'type' => 'info'
      );
      $options[] = array(
        'name' => 'Links Footer Section',
        'type' => 'info',
        'class' => 'toggle-slide',
        'id' => 'second'
      );
      $options[] = array(
        'id' => 'show_footer_sec_s2',
        'desc' => 'Show Links Footer Section',
        'std' => 1,
        'type' => 'checkbox',
      );
      $options[] = array(
        'id' => 'footer_sec_s2_title',
        'desc' => 'Title',
        'std' => 'Useful links',
        'type' => 'text'
      );
      $options[] = array(
        'id' => 'footer_sec_s2_num',
        'desc' => 'Number of Info',
        'std' => '4',
        'type' => 'text',
        'class' => 'mini'
      );
      if(of_get_option('footer_sec_s2_num') > 0? $cant_ = of_get_option('footer_sec_s2_num'):$cant_=4);
        for($i=1; $i<=$cant_; $i++){
          $options[] = array(
            'name' => 'Link '.$i,
            'type' => 'info',
            'class' => 'toggle-second'
          );
          $options[] = array(
            'id' => 'footer_sec_s2_info_v'.$i,
            'desc' => 'Value',
            'std' => 'Links Example',
            'type' => 'text',
            'class' => 'toggle-second'
          );
          $options[] = array(
            'id' => 'footer_sec_s2_info_link'.$i,
            'desc' => 'About Us',
            'type' => 'text',
            'class' => 'toggle-second'
          );
       	}

         
				// Tags Footer Section
				$options[] = array(
          'name' => '',
          'type' => 'info'
        );
        $options[] = array(
          'name' => 'Tags Footer Section',
          'type' => 'info'
        );
        $options[] = array(
          'id' => 'show_footer_sec_s3',
          'desc' => 'Show Tags Footer Section',
          'std' => 1,
          'type' => 'checkbox'
        );
        $options[] = array(
          'id' => 'tag_num',
          'desc' => 'Number of Tag to show in footer',
          'std' => '7',
          'type' => 'text',
          'class' => 'mini'
        );


				// Testimonials Footer Section
				$options[] = array(
          'name' => '',
          'type' => 'info'
        );
        $options[] = array(
          'name' => 'Testimonials Footer Section',
          'id' => 'fourth',
          'type' => 'info',
          'class' => 'toggle-slide'
        );
        $options[] = array(
          'id' => 'show_footer_sec_s4',
          'desc' => 'Show Testimonials Footer Section',
          'std' => 1,
          'type' => 'checkbox',
        );
        $options[] = array(
          'id' => 'footer_sec_s4_num',
          'desc' => 'Number of Comment',
          'std' => '4',
          'type' => 'text',
          'class' => 'mini'
        );
				if(of_get_option('footer_sec_s4_num') > 0? $cant_ = of_get_option('footer_sec_s4_num'):$cant_=4);
            for($i=1; $i<=$cant_; $i++){
              $options[] = array(
                'name' => 'Testimonial '.$i,
                'type' => 'info',
                'class' => 'toggle-fourth toggle-opt'//ct-show_footer_sec_s4',
            );
              $options[] = array(
                'id' => 'footer_sec_s4_coment'.$i,
                'desc' => 'Coment Text',
                'std' => 'Lorem ipsum ea cum congue bonorum, pri no natum clita. His ne vide omnis forensibus. Eum cetero imperdiet et.!',
                'type' => 'textarea',
                'class' => 'toggle-fourth toggle-opt'//ct-show_footer_sec_s4',
              );
              $options[] = array(
                'id' => 'footer_sec_s4_author'.$i,
                'desc' => 'Author',
                'std' => 'David Smich - Web Desinger',
                'type' => 'text',
                'class' => 'toggle-fourth toggle-opt'//ct-show_footer_sec_s4',
              );
            }

            // Coopring Footer Section
            $options[] = array(
              'name' => '',
              'type' => 'info'
            );
            $options[] = array(
              'name' => 'Copyright Configuration Section',
              'type' => 'info'
            );
            $options[] = array(
              'id' => 'show_copyright',
              'desc' => 'Show Copyright Configuration Section',
              'std' => 1,
              'type' => 'checkbox'
            );
            $options[] = array(
              'id' => 'copyright_text',
              'desc' => 'Copyright description',
              'std' => '2014 Full Estate - Real Estate Template. All rights reserved.',
              'type' => 'text'
            ); 
            $options[] = array(
              'id' => 'copyright_text_link',
              'desc' => 'Link',
              'type' => 'text'
            );

						// Social Footer Section
            $options[] = array(
              'name' => '',
              'type' => 'info'
            );
						$options[] = array(
              'name' => 'Social Footer Links',
              'type' => 'info'
            );
            $options[] = array(
              'id' => 'copyright_text_number',
              'desc' => 'Number of Social Links',
              'std' => '3',
              'type' => 'text',
              'class' => 'mini'
            );
            if(of_get_option('copyright_text_number')?$cant=of_get_option('copyright_text_number'):$cant=3);
            
            for($i=1; $i<=$cant; $i++){
              $options[] = array(
                'name' => 'Social Link',
                'type' => 'info'
              );
              foreach(font_awesome_icon('copy_ico'.$i) as $val){
                $options[] = $val;
              }
              $options[] = array(
                'id' => 'copy_text_link_title'.$i,
                'desc' => 'Title',
                'std' => 'facebook',
                'type' => 'text'
              ); 
              $options[] = array(
                'id' => 'copy_text_link_link'.$i,
                'desc' => 'Link',
                'type' => 'text'
              );
            } 
?>