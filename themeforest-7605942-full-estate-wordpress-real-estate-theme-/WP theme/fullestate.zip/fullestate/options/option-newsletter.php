<?php
    $options[] = array(
        'name' => 'Newsletter',
        'type' => 'heading',
		'std'  => 'cogs'
    );

		/*========  Newsletter =============*/

    $options[] = array(
        'name' => 'Newsletter Configuration Zone',
        'type' => 'info'
    );
        $options[] = array(
            'id' => 'news_title',
            'desc' => 'Newsletter Title',
            'std' => 'STAY INFORMED',
            'type' => 'text'
        );
        $options[] = array(
            'id' => 'news_subtitle',
            'desc' => 'Newsletter Subtitle',
            'std' => '- Lorem ipsum dolor sit amet, consectetuer adipiscing elit Lorem ipsum.',
            'type' => 'textarea'
        );
        $options[] = array(
            'id' => 'news_form',
            'desc' => 'Newsletter form name. [sidebar-name]',
            'type' => 'text'
        );
			 $options[] = array(
            'name' => 'Templates to show Newsletter Zone',
            'type' => 'info'
        );
        $pages = array();
        foreach(get_pages() as $titles){
            $tit = $titles->post_name;
            $pages[$tit] = $titles->post_title;
        }
        $pages['index'] = 'Index';
        $pages['single'] = 'Single Post';
        $pages['single-property'] = 'Single Property';
        $pages['404'] = '404 page';
        $options[] = array(
            'id' => 'news_template',
            'options' => $pages,
            'type' => 'multicheck',
        );
?>