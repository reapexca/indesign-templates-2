<?php get_header();?>
<!-- Container-->
<div class="container">
  <div class="paddings">
    
    <div class="row">   
      <!-- Blog Post-->
      <div class="col-md-8 col-lg-9">
        <?php get_template_part( 'loop' ); ?>       
     </div>
     <!-- End Blog Post-->
                  
      <!-- Sidebars-->
      <div class="col-md-4 col-lg-3">
        <?php get_sidebar( 'content' ); ?>
      </div>
      <!-- Sidebars-->
    </div>
  </div>
</div>
<?php get_footer(); ?>