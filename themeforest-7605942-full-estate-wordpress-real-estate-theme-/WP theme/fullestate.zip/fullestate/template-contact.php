<?php
/*
Template Name: Template Contact
*/
   get_header();
?>
<div class="container">
	<div class="row paddings">
      <div class="col-md-5">
          <h2><?php echo (function_exists('get_field'))?get_field('form_title'):'Contact Form';?></h2>
          <?php echo (function_exists('get_field'))?do_shortcode(get_field('form_id')):'No form to load';?> 
          <div id="result"></div> 
      </div>
      <?php
           if(function_exists('get_field')){
       ?>
      <div class="col-md-7">
          <h2><?php echo get_field('agents_info_title');?></h2>
         <?php echo get_field('agent_info');?>
  
          <div class="divisor divisor_services">
              <div class="circle_left"></div>
              <div class="circle_right"></div>
          </div>
        	
          <div class="row">
           <?php
                if(get_field('agent_to_show') !== false){
                    foreach(get_field('agent_to_show') as $maison_key){     
                      $maison_val = get_fields($maison_key->ID);
            ?>
                
                    <div class="col-sm-6 col-md-6">
                      <div class="item_agent row">
                          <div class="col-md-5 image_agent">
                              <img src="<?php echo $maison_val['image'];?>" alt="<?php echo $maison_val['name']?>">
                          </div>
                          <div class="col-md-7 info_agent">                                
                              <ul>
                                  <?php
                                      foreach($maison_val['data'] as $maison_data){     
                                  ?>
                                  <li>
                                      <i class="<?php echo $maison_data['icon'];?>"></i>
                                      <a href="<?php echo $maison_data['link'];?>" target="<?php echo $maison_data['target_data_agent']?>">
                                          <?php echo $maison_data['text'];?>
                                      </a>
                                  </li>
                                  <?php
                                      }
                                  ?>
                              </ul>                                        
                          </div>
                        </div>  
                    </div>         
            <?php       
                 }
               }
            ?>
        </div>
      <?php
          }
      ?>
		</div>
	</div> 
</div>
<?php
     get_footer();
 ?>