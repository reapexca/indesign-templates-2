<?php get_header();?>
<section class="section_area">
    <div class="container center"> 
      	<div class="row paddings error_page"> 
        <?php
        if(function_exists('of_get_option')){
            echo '<h1>'.of_get_option('404_title').'</h1>';
            echo '<p>'.maison_insert_br(of_get_option('404_explain')).'</p>';
            echo '<a href="'.get_home_url().'" class="button">';
                echo of_get_option('404_botton');
            echo '</a>';
        }else{
            echo '<h1>404</h1>';
            echo '<p>We\'re sorry, but the page you were looking for doesn\'t exist.</p>';
            echo '<a href="'.get_home_url().'" class="button">';
                echo 'Return Home';
            echo '</a>';
        }
        ?>
      	</div>
    </div>
</section>
<?php get_footer(); ?>
